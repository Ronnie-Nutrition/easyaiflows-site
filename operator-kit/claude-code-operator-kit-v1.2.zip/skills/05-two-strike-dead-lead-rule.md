# The 2-Strike Cold Rule + Dead Lead Rule

**The two pruning rules that keep your pipeline alive — and stop you from burning your network.**

> *Written by Ronnie Craig — operator who learned the hard way that "one more follow-up" is how you turn warm leads into people who block you.*

---

## What this PRD is

If you do outreach for any length of time, your tracker fills up with leads who went cold. The instinct is to keep following up "just in case." That instinct will destroy you.

This PRD teaches you the two pruning rules that protect:

1. **Your network** (people stop engaging with you when you over-message)
2. **Your sanity** (chasing cold leads is the #1 cause of outreach burnout)
3. **Your time** (every minute on a dead lead is a minute not on a fresh one)

## Who this is for

- You run outreach across DMs, iMessage, email, or all of the above
- You have a growing tracker / spreadsheet / CRM of "people I should follow up with"
- You feel guilt or anxiety about letting leads "go"
- You want a clear, written rule so you stop overthinking

## Outcome

After implementing these rules:
- Your tracker stays under 200 active leads (instead of bloating to 1,000+ dead names)
- You spend 100% of your outreach time on warm + fresh leads
- Cold leads either reactivate cleanly or exit cleanly — no ambiguity
- You stop sending the "just checking in" message that everyone ignores

---

## The Dead Lead Rule (3 unanswered = dead)

### The rule, in one sentence

> **If a lead has 3 unanswered messages from you, they are DEAD. Stop messaging. Mark in tracker. Free the slot for someone fresh.**

That's it. No exceptions.

### Why 3, not 5 or 7?

- Touch 1: Initial. They might've missed it.
- Touch 2: Reasonable follow-up. They might've been busy.
- Touch 3: Last reasonable touch. If they wanted to reply, they would've by now.
- Touch 4+: You're now in stalker territory. Their next move is to block you, not buy.

### What "unanswered" means

| Counts as a touch | Doesn't count |
|---|---|
| ✅ DM where you asked a question | ❌ Liking their story |
| ✅ iMessage with an offer or check-in | ❌ Commenting on a post |
| ✅ Voice note | ❌ Story view |
| ✅ Email | ❌ Friend / follow request |

Only count actual messages.

### What to do when you mark a lead DEAD

1. **Update the tracker.** Change their bucket to "Cold / Dead." Note the date.
2. **Don't delete them.** Keep them in the archive. They might re-engage in 6 months with new context.
3. **Replace the slot.** Add a fresh harvested name to today's outreach queue.
4. **Do not message them again** — unless they engage with you first (like a post, follow back, etc.).

---

## The 2-Strike Cold Rule (interest + silence = dead immediately)

This is the more aggressive version. It applies in a specific situation.

### The rule

> **If a lead expressed clear interest ("yes," "I'll come," "sounds great") AND THEN went silent through 2 unanswered follow-ups — mark DEAD immediately. Don't wait for strike 3.**

### Why this is different from the 3-strike rule

A cold lead going silent is normal — they were never warm.

A WARM lead saying "yes" and then ghosting is a different signal. It usually means:
- They had a momentary spark and lost interest
- They felt social pressure to say yes
- Something changed (lost job, broke up, moved)

Whatever the reason: **the warmth is gone**. Chasing it makes you look needy, lowers your status, and reduces the (small) chance they re-engage on their own later.

### Examples of when 2-strike applies

- Customer said "I'll be in tomorrow!" → no-show → you message once → no reply → you message again → no reply → DEAD.
- Prospect said "Yes I want a sample!" → you send free sample → no thank-you, no follow-up → you message → no reply → DEAD.
- Lead said "Let's set up a call" → ghosted Calendly → you message twice → no reply → DEAD.

### Why this protects your status

In status terms: **you saying "let me check in again" twice after they ghosted lowers you in their eyes.** It signals you need them more than they need you. That's the opposite of the energy that closes deals.

The 2-strike rule preserves your status by saying: I made my offer, I followed up reasonably, the ball was in your court, you didn't move it. Done.

---

## The "No Recycling" Rule (the silent corollary)

This one's harder to follow but matters more than people realize.

### The rule

> **If a lead has 2+ unanswered messages AND no new engagement since the last touch — do not include them in today's outreach batch. Skip and replace with a harvest name.**

### What this prevents

The lazy operator opens the tracker, sees 50 "leads" with last-touch dates from weeks ago, and messages them again. That's recycling.

The disciplined operator messages from:
1. Today's fresh harvest (new engagers)
2. People at the next-touch step in the cadence (touch 2, touch 3)

Anyone past 3 touches with no engagement = NEVER in today's batch.

---

## How to track these rules in practice

Your tracker needs 2 columns to enforce these rules:

| Column | What it holds |
|---|---|
| `last_touch_count` | 1, 2, or 3 |
| `last_engagement_date` | When they last engaged with you (replied, liked, commented) |

The Monday morning ritual:
1. Sort by `last_touch_count` DESC
2. Anyone at 3 with no `last_engagement_date` in the last 30 days → mark DEAD
3. Anyone at 2 who said "yes" and then went silent → apply 2-strike, mark DEAD
4. Save the result. Lead slots are now free for fresh harvest.

---

## The reactivation exception (rare, but useful)

After 90+ days of DEAD status, you can attempt ONE reactivation under specific conditions:

### When reactivation is allowed

- You launched a new product they specifically asked about
- A major life event (new location, new offer, anniversary)
- They re-engaged with your content (followed back, liked a recent post)

### The reactivation message

> "Hey [name], it's been a while. Quick update: [the new thing]. Thought of you because [specific reason]. No pressure either way — just figured I'd share."

### The rule for reactivation

ONE message. ONE shot. If they don't reply, they go back to DEAD. No follow-up.

---

## Why operators resist these rules (and the answer)

### "What if they were just busy?"
After 3 unanswered messages over 2–4 weeks, they're not "busy." They're uninterested. The longer you pretend otherwise, the more you waste your own time.

### "What if I miss a sale?"
You won't. The math says: every minute spent chasing a dead lead is a minute not spent on someone fresh. Fresh leads close at 5–15x cold rates. The expected value of pruning is strongly positive.

### "But this one really seemed warm…"
Trust the rule, not the vibe. The 2-strike rule exists exactly because operators trust the vibe instead of the data, and burn warm-once-leads by chasing.

### "What if I feel guilty?"
You'll feel less guilty when your pipeline is healthier and your conversations are warmer. Pruning is generous — to your remaining leads and to yourself.

---

## A working example

Let's say you start with a tracker of 200 leads.

After applying the rules:
- 50 leads have 3+ unanswered → mark DEAD → 150 active leads
- 20 leads said "yes" then went silent twice → 2-strike DEAD → 130 active
- 30 leads at touch 2 or 3 with NO engagement since → no-recycling → 100 active

You went from 200 ambiguous "leads" to 100 active ones you can actually move. Outreach time per day drops in half. Reply rate goes UP because you're only touching people who are likely to reply.

This is the pruning win. Try it for 30 days.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Excel / Notion / CRM | Tracker with the 2 required columns | Free |
| **Time** | **10 min/Monday pruning ritual** | — |

---

## Common questions

**Q: Can I make exceptions for friends / referrals?**
A: Yes — for personal contacts, the rules don't apply. They're for outreach to prospects. A friend ghosting your DM is just a friend being a friend.

**Q: What if a "dead" lead reaches out 6 months later?**
A: Welcome them back like nothing happened. The DEAD status was your decision, not theirs. If they re-engage, they're alive again.

**Q: Should I send a "breakup" message before marking dead?**
A: No. The cliché "I'll stop bothering you" message reads as manipulative — like you're trying to guilt them into replying. Just stop messaging. Silent exit is cleaner.

**Q: How do I emotionally let go of a dead lead?**
A: Move the next fresh harvest name into their slot the same day. The brain doesn't grieve when there's already a replacement.

---

## What's next

These rules ASSUME you have fresh harvest replacing the dead leads. If you don't, see the **Content-First Lead Harvest Workflow** (skill #4) — it's the engine that keeps the pipeline supplied.

And the rhythm that runs both of those is the **100-Conversation Daily Outreach System** (skill #3).
