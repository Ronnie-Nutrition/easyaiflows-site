# Loyalty + Check-In via GHL Custom Fields

**Build a working visit-based loyalty system in GHL using only custom fields and a check-in URL — no separate loyalty app, no extra subscription.**

> *Written by Ronnie Craig — operator running this exact system at my Pearland nutrition club. Most of my regulars participate, and a healthy share earn a reward within their first 90 days.*

---

## What this PRD is

Most loyalty programs are either:
- ❌ Punch cards (lose them, forget them, don't drive data)
- ❌ Separate loyalty apps ($50–200/mo + customer friction to download an app)
- ❌ Complex points programs nobody understands

This PRD shows you how to build a **simple, working, visit-based loyalty program** using only GHL custom fields and a check-in URL. No extra cost, no extra app, no customer download required.

The system:
1. Customer visits → scans QR or taps a link → enters phone → gets +10 points
2. At 100 points → coupon for free product
3. GHL automatically sends reward DM/SMS when threshold hit

## Who this is for

- Local biz operators (food, services, retail) with repeat-customer dynamics
- You have GHL set up (see: GHL Quick-Start, skill #13)
- You want a loyalty program that runs itself

## Outcome

After this PRD:
- Customers can check in at every visit with a simple URL
- Points accumulate in GHL custom fields automatically
- Reward messages trigger automatically at 100 points
- You have a database of every visit, every customer, every reward

---

## The system (high-level flow)

```
Customer visits store
   ↓
Scans QR / taps link on owner's device
   ↓
Enters phone number on simple web form
   ↓
Backend looks up phone in GHL
   ├── Found: increment Rewards Points field (+10)
   └── New: create contact, set Member Since, +10 points
   ↓
If points >= 100:
   ├── Set Rewards Coupon field to "FREE_SHAKE_<random_code>"
   ├── Reset points to (current - 100)
   └── Trigger workflow → DM customer "You earned a free shake!"
```

That's it. The entire mechanic.

---

## Phase 1 — GHL custom field setup

You already have these from the GHL Quick-Start (skill #13). If not, build them:

| Field name | Type | Purpose |
|---|---|---|
| Rewards Points | Number | Current point balance |
| Total Visits | Number | Lifetime visit count |
| Last Visit Date | Date | Most recent visit |
| Member Since | Date | First-ever check-in |
| Member Status | Single-line text | "active" / "lapsed" / "churned" |
| Rewards Coupon | Single-line text | Current redeemable code (or empty) |

Save each field's **Field ID** from GHL Settings → Custom Fields. You'll need them in code.

---

## Phase 2 — The check-in page (HTML + Node)

A single-page web form. Hosted on your domain or as a route on your existing site.

### The HTML (simple form)

```html
<!DOCTYPE html>
<html>
<head>
  <title>Check In — Earn Rewards</title>
  <style>
    body { font-family: -apple-system, sans-serif; padding: 40px 20px; max-width: 480px; margin: auto; text-align: center; }
    h1 { font-size: 28px; }
    input[type="tel"] { font-size: 18px; padding: 14px; width: 100%; box-sizing: border-box; border-radius: 8px; border: 1px solid #ccc; }
    button { font-size: 18px; padding: 14px 28px; background: #d63031; color: white; border: none; border-radius: 8px; margin-top: 16px; cursor: pointer; }
    .success { color: green; font-size: 20px; margin-top: 20px; }
    .reward { color: #b8860b; font-weight: bold; font-size: 22px; margin-top: 20px; }
  </style>
</head>
<body>
  <h1>Check In</h1>
  <p>Enter your phone to earn +10 points.</p>
  <form id="checkin">
    <input type="tel" name="phone" placeholder="Phone (digits only)" required pattern="[0-9]+" />
    <button type="submit">Check In</button>
  </form>
  <div id="result"></div>

  <script>
    document.getElementById('checkin').addEventListener('submit', async (e) => {
      e.preventDefault();
      const phone = e.target.phone.value.replace(/\D/g, '');
      const r = await fetch('/api/checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });
      const data = await r.json();
      const result = document.getElementById('result');
      if (data.reward) {
        result.innerHTML = `<div class="reward">🎉 You hit 100! Free shake unlocked. Code: ${data.coupon}</div>`;
      } else {
        result.innerHTML = `<div class="success">✅ +10 points! Total: ${data.points}</div>`;
      }
      e.target.reset();
    });
  </script>
</body>
</html>
```

### The Node API endpoint

```javascript
const POINTS_PER_VISIT = 10;
const REWARD_THRESHOLD = 100;
const GHL_API_TOKEN = process.env.GHL_API_TOKEN; // pit-...
const GHL_LOCATION_ID = process.env.GHL_LOCATION_ID;

// Your custom field IDs from GHL Settings → Custom Fields
const GHL_FIELDS = {
  rewardsPoints: 'YOUR_FIELD_ID_1',
  totalVisits:   'YOUR_FIELD_ID_2',
  lastVisitDate: 'YOUR_FIELD_ID_3',
  memberSince:   'YOUR_FIELD_ID_4',
  memberStatus:  'YOUR_FIELD_ID_5',
  rewardsCoupon: 'YOUR_FIELD_ID_6',
};

async function ghlRequest(method, path, body) {
  const r = await fetch(`https://services.leadconnectorhq.com${path}`, {
    method,
    headers: {
      'Authorization': `Bearer ${GHL_API_TOKEN}`,
      'Content-Type': 'application/json',
      'Version': '2021-07-28',
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  return r.json();
}

async function handleCheckin(req, res) {
  const { phone } = req.body;
  if (!phone || phone.length < 10) {
    return res.status(400).json({ error: 'Invalid phone' });
  }

  // 1. Look up contact by phone
  const search = await ghlRequest('GET',
    `/contacts/search/duplicate?locationId=${GHL_LOCATION_ID}&number=${encodeURIComponent('+1' + phone)}`);

  let contact = search.contact;

  // 2. If not found, create
  if (!contact) {
    const created = await ghlRequest('POST', '/contacts/', {
      locationId: GHL_LOCATION_ID,
      phone: '+1' + phone,
      tags: ['loyalty', 'walk-in'],
      customFields: [
        { id: GHL_FIELDS.memberSince, value: new Date().toISOString().slice(0,10) },
        { id: GHL_FIELDS.memberStatus, value: 'active' },
      ],
    });
    contact = created.contact;
  }

  // 3. Compute new values
  const currentPoints = Number(getField(contact, GHL_FIELDS.rewardsPoints)) || 0;
  const currentVisits = Number(getField(contact, GHL_FIELDS.totalVisits)) || 0;
  let newPoints = currentPoints + POINTS_PER_VISIT;
  let coupon = '';

  if (newPoints >= REWARD_THRESHOLD) {
    coupon = 'FREE_SHAKE_' + Math.random().toString(36).slice(2, 8).toUpperCase();
    newPoints = newPoints - REWARD_THRESHOLD; // roll over remainder
  }

  // 4. Update contact
  await ghlRequest('PUT', `/contacts/${contact.id}`, {
    customFields: [
      { id: GHL_FIELDS.rewardsPoints, value: newPoints },
      { id: GHL_FIELDS.totalVisits, value: currentVisits + 1 },
      { id: GHL_FIELDS.lastVisitDate, value: new Date().toISOString().slice(0,10) },
      ...(coupon ? [{ id: GHL_FIELDS.rewardsCoupon, value: coupon }] : []),
    ],
  });

  // 5. If reward earned, trigger workflow (set up in GHL UI separately)
  if (coupon) {
    await ghlRequest('POST', `/contacts/${contact.id}/workflow/YOUR_REWARD_WORKFLOW_ID`);
  }

  res.json({
    points: newPoints,
    visits: currentVisits + 1,
    reward: !!coupon,
    coupon: coupon || undefined,
  });
}

function getField(contact, fieldId) {
  const f = (contact.customFields || []).find(x => x.id === fieldId);
  return f ? f.value : null;
}
```

### Mounting it in Express

```javascript
app.use(express.json());
app.post('/api/checkin', handleCheckin);
app.get('/checkin', (req, res) => res.sendFile('checkin.html'));
```

---

## Phase 3 — The GHL reward workflow

Trigger an automated DM/SMS when a customer hits the threshold.

### Build the workflow

1. **GHL → Automation → Workflows → New Workflow**
2. Name: "Loyalty Reward Earned"
3. Trigger: **Customer manually enrolled** (your code will enroll them via API)
4. Action: **Send SMS** or **Send DM**

### Sample message

> 🎉 Hey {{contact.first_name}}! You hit 100 visits points — your next [free product] is on the house. Show this code at checkout: {{contact.rewards_coupon}}
> Thanks for being a regular.

5. Copy the workflow ID and paste into the Node code (`YOUR_REWARD_WORKFLOW_ID`).

---

## Phase 4 — The QR code or owner-device URL

You don't make customers download an app. You make it simple:

### Option A: Owner-device check-in

- Owner / staff opens `https://yoursite.com/checkin` on a tablet at the counter
- Customer enters their own phone
- Owner confirms +10 points appeared

Pros: zero friction for the customer.
Cons: requires staff attention each visit.

### Option B: Customer-scanned QR

- Print a QR code linking to `https://yoursite.com/checkin`
- Display at the counter / on the table
- Customer scans + checks in themselves

Pros: zero staff time.
Cons: ~30% of customers won't bother — they're holding food.

### Recommendation: Run BOTH

- Owner asks "did you check in?" when handing over the product
- QR is the customer's backup if owner forgets

---

## Phase 5 — Maintaining the system

### Weekly check (5 min)

- Filter contacts by `Last Visit Date` < 30 days → tag as "active"
- Filter by `Last Visit Date` 30–60 days ago → tag as "lapsed"
- Filter by `Last Visit Date` > 60 days → tag as "churned"

(This can be automated via a GHL workflow — but manual is fine for v1.)

### Monthly check (10 min)

- Pull a count of: total members, active, lapsed, churned
- Reward redemptions in last 30 days
- Visits per customer (should be ~2-4 for a healthy local biz)

---

## Common pitfalls

### Pitfall 1: Letting customers self-check-in unmonitored
Some will spam the form. Counter-fix: require staff confirmation, OR cap +points to 1/day per phone in your code (`if (lastVisitDate === today) return res.json({error: 'Already checked in today'})`).

### Pitfall 2: Forgetting to set the workflow ID in code
You build the workflow but don't paste its ID into Node. Rewards earn but no SMS fires. Test end-to-end after setup.

### Pitfall 3: Custom field IDs change
GHL custom field IDs are stable but the field NAMES can be renamed. Always reference by ID, not name.

### Pitfall 4: Phone number formatting mismatch
GHL stores with `+1`. Your form receives 10 digits. Always normalize to `+1` before lookup.

---

## Common questions

**Q: Can I tier the rewards (10/25/50 visits)?**
A: Yes — make the threshold an array `[100, 250, 500]` and check each. But for v1, one threshold is simpler.

**Q: What about gift cards instead of free products?**
A: Same mechanic, different reward content. Easy to swap.

**Q: Can customers check their points themselves?**
A: Build a `/my-points` page that takes phone → shows their current points. Optional, low-priority.

**Q: What if customers don't have phones?**
A: Use email as an alternate ID. Most local biz operators find ≥95% have phones, so phone is fine as v1.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Go High Level | The CRM + workflow engine | (already paying — skill #13) |
| Node.js server | Host the check-in endpoint | Your existing infra |
| QR code generator | Print at counter | Free (qrcode-monkey.com etc.) |
| **Time to implement** | **2–3 hours one-time** | — |

---

## What's next

Loyalty + check-in is the foundation. Layer in the **Bring-A-Friend Lead Magnet System** (skill #8) — bring-a-friend visits award DOUBLE points, creating a referral compounding loop on top of the loyalty mechanic.
