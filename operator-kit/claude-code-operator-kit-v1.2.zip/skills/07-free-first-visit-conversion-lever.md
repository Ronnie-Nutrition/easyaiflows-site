# Free-First-Visit Conversion Lever

**The one offer that beats every "discount" for local biz acquisition — and how to build it without losing money.**

> *Written by Ronnie Craig — operator who uses a free-first-visit offer to convert cold DMs into walk-in customers at my Pearland nutrition club. It's the highest-converting offer I've tested.*

---

## What this PRD is

If you run a local business — gym, salon, food, services — there's exactly ONE acquisition offer that works in 2026: **the free first visit**. Not "20% off." Not "buy one get one." Free.

This PRD teaches you:

1. Why "free first" outperforms every other offer for local biz
2. How to structure it so you don't lose money
3. The exact DM script that converts cold leads into walk-ins
4. The follow-up sequence that turns the visit into a repeat customer

## Who this is for

- Local biz owners (5–25 mile catchment)
- Anyone using DMs, ads, or referrals to drive in-person visits
- Businesses where the first transaction = the customer trial

## Outcome

After implementing this:
- Higher DM → visit conversion rate (significantly higher than discount-based offers)
- Lower cost per acquired customer than promo discounts
- More word-of-mouth (people share free experiences harder than discounted ones)

---

## Why "free first" beats "% off"

| Offer | Mental friction | What it signals |
|---|---|---|
| "20% off your first visit" | Some — they still have to spend | "We need your money" |
| "Buy one get one" | Medium — they have to buy first | "We're discounting because nobody's coming" |
| "First visit on us" | Almost zero | "We're confident — try it, see for yourself" |

The free first visit is the only offer that removes 100% of the financial risk for the buyer. That's why it converts.

### The status math

Discounts lower your perceived price (and your status). "Free" is OUTSIDE the price game entirely — it's a gift. A gift positions you as confident and generous. Discounts position you as desperate.

---

## How to structure it without losing money

The free-first-visit only works if the math works. Here's how to set it up.

### The "loss leader" model

You give the first visit free. You make money on:

1. **Repeat visits** (the customer comes back at full price)
2. **Add-ons during the free visit** (water, supplements, premium upgrade — these are optional, NOT required)
3. **Referrals** (free customer becomes a referrer)

### The math you need to hit

- **Your average customer comes back X times before churning.** Compute X from your data. (At a nutrition club, average lifetime is ~12 visits.)
- **Each return visit makes you $Y in margin.** (For a $10 smoothie with $3 COGS, that's $7 margin.)
- **Your free first visit costs you $Z in COGS.** (Same drink, $3 in product cost.)

If X × Y > Z, the free-first-visit is profitable. For most local biz, X × Y is 10–50x Z. The math overwhelmingly works.

### Limit the offer so it doesn't get abused

- **One per person, ever.** Track in your CRM by name + phone.
- **Specific items only.** "First smoothie on us" — not "anything in the store free."
- **Time-limited.** "Use it within 14 days." Forces action.
- **Requires showing up in person.** Not online order. The visit is the value.

---

## The DM script that drives the visit

Here's the script that consistently converts cold DMs into in-store visits.

### For an Instagram or TikTok engager:

> "Hey [name]! Thanks for [following / liking the reel]. I run [your business] in [city] — first [product] is on me whenever you wanna swing by. Just ask for [your name] when you come in."

### For a referred lead:

> "Hey [name]! [Mutual friend] mentioned you. We have [thing they'd care about based on what mutual said]. Want me to set up a free [product] for you? Just need to know when you can swing by."

### For a re-engager (someone you talked to before):

> "Hey [name], we're back to running our 'first one on us' for the [season / month]. If you're around [city], swing by — I'll set you up."

### What makes these work

- **Specific location reference** (people trust local before they trust "online business")
- **Personal name signing** ("ask for Ronnie") — turns it from "a business" to "a person"
- **No high-pressure CTA** ("whenever you wanna swing by")
- **Time anchor optional** (mention "this week" if you want urgency, skip if you want lower pressure)

---

## The in-person experience that converts the visit to a repeat

The free visit is your shot to lock in a long-term customer. Don't blow it.

### The 4-part welcome ritual

**1. Greet by name.**
"You must be [name] — Ronnie. Glad you came in."

You learned their name from the DM. Use it. This signals you remember them, which signals they matter.

**2. Walk them through the menu / offer / experience.**
Don't make them figure it out. 90 seconds of "here's what we do, here's what most people start with."

**3. Make the first one.**
Make it well. This is the product experience that decides if they come back.

**4. Ask one personal question.**
"What brings you in today?" or "What are you working on right now?" — listen, don't pitch. The answer tells you what to follow up on.

### What NOT to do during the free visit

- ❌ Pitch a membership or subscription (too soon)
- ❌ Ask them to sign up for a loyalty program (clunky during a first visit)
- ❌ Take a photo without asking (creepy and the photo's bad anyway)
- ❌ Hand them a brochure (nobody reads brochures)

### The ONE thing to ask before they leave

> "Mind if I follow up in a few days to see how you liked it?"

This earns permission for the next-touch DM. 95% say yes. Now you have a clean follow-up signal.

---

## The follow-up sequence (3 touches, 2 weeks)

After the free visit, the goal is to convert them to a 2nd (paid) visit. Here's the cadence:

### Touch 1 — 48 hrs after visit
> "Hey [name], how'd you feel after the [product] from Tuesday? Any energy difference?"

Open-ended, no sales pitch. You're showing you remember.

### Touch 2 — 5 days after visit
> "Hey [name], you're due for round 2 — running a [thing] that I think you'd like. Want me to have it ready for you Saturday?"

Soft sales pitch tied to a specific, time-bound visit.

### Touch 3 — 12 days after visit (only if no reply to touch 2)
> "Hey [name], no pressure — just wanted to check if I should keep a [product] for you this weekend or let it go. Either's fine."

The "either's fine" framing removes the sales pressure. If they don't respond after touch 3, apply the **2-Strike + Dead Lead Rule** (skill #5).

---

## What if they don't come in after promising?

### The 2-strike applies

If they said "I'll come this week" and didn't show:
- Touch 1: "Hey [name], everything ok? Wanted to make sure I got the timing right."
- Touch 2: "Hey [name], we're still here when you're ready. No pressure."
- No reply after 2 → DEAD per the 2-strike rule.

Don't chase. Free up the slot. Move to the next harvested name.

---

## Common questions

**Q: Won't people abuse the free offer?**
A: A small percentage will. The math still works because lifetime customer value swamps the loss. Track names + phones to prevent multi-claims.

**Q: What if my COGS are high (like a salon service)?**
A: Make it a "free service add-on" instead of free full service. E.g., free brow shape with paid cut. Or free 15-min consult, not full massage.

**Q: How do I track who used it?**
A: Phone number + name in your CRM. (See: GHL Quick-Start, skill #13.) If you don't have a CRM, a Google Sheet works for v1.

**Q: Can I require them to give me their email/phone first?**
A: Yes — that's the entire point. The free offer in exchange for contact info IS a lead magnet. Just frame it as "I'll text you when it's ready" instead of "give me your data."

**Q: What if they come in for the free drink, never buy anything, and leave?**
A: That happens 20–30% of the time. The other 70–80% who become repeat customers more than cover it. Accept the loss rate.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Your CRM (or Google Sheet) | Track who used the offer | Free |
| Phone / DMs | Follow-up | Free |
| Time | 5 min per redeemed visit | — |

---

## What's next

This offer drives a single first visit. The next leverage is the **Bring-A-Friend Lead Magnet System** (skill #8) — which lets one happy customer bring in 1–3 more without you doing any outreach. Stack the two and your acquisition cost approaches zero.
