# How to Build an iOS App with AI (Without Being a Coder) — PRD Playbook

**The non-coder's playbook for shipping a real iOS app using AI tools.**

> *Written by Ronnie Craig — operator who shipped 3 iOS apps (DM Flow, CalTrackPro, Entrepreneurs Bible) without being a "real" engineer. This is the workflow that worked.*

---

## What this PRD is

A PRD (Product Requirements Document) is the single document that turns a fuzzy app idea into a thing AI tools can actually build for you. Without one, you'll burn weeks asking Claude / Cursor / ChatGPT to "build me an app" and getting half-finished spaghetti. With one, you ship.

This PRD teaches you:

1. How to validate the idea before you write a single line of code
2. How to write a real PRD (the format Claude actually responds well to)
3. The right tech stack for a non-coder (and which ones to avoid)
4. The exact AI-assisted build workflow
5. The submission steps Apple won't warn you about

## Who this is for

- You're not a software engineer
- You have an app idea (productivity, business tool, side hustle, personal use)
- You've maybe tried "vibe coding" and hit a wall
- You want a clear, repeatable process — not theory

## Outcome

By the end of this playbook, you have:
- A validated PRD for your app
- A working build environment (Xcode + AI tools)
- A clear weekly cadence to ship features
- A submission checklist that doesn't surprise you on day-of

---

## Phase 0 — Validate the idea (1 hour)

**Do not skip this.** 80% of solo iOS apps die because nobody wanted them. AI will gladly help you build a thing nobody asked for.

### The 3-question filter

1. **Who specifically needs this?** ("Everyone" is wrong. Name a person — your sister, the guy at the gym, your downline coach.)
2. **What do they do today instead?** (If the answer is "nothing," that's actually bad — it usually means it's not a real problem yet.)
3. **What would they pay $5/month to avoid?** (Pain you can put a price on is real pain.)

If you can't answer all three in concrete sentences, you don't have an app idea yet — you have a hobby.

### Cheap validation moves before building

- **Post the idea in 3 Reddit / X / Facebook groups** where your "who" hangs out. Ask: "Would you use this? Why or why not?" Count actual replies, not likes.
- **Make a one-page landing page** ($0 with Gumroad or Carrd) and run $20 of Meta ads to it. If nobody enters their email, nobody wants the app.
- **DM 5 people in your target audience** and ask if they'd test a beta. Two yeses = move forward. Five maybes = no signal.

> 💡 **Ronnie's note:** CalTrackPro started because my wife and I both wanted faster calorie logging and the apps we tried were bloated. I validated by asking 10 Nutrition Hub customers. 7 said "I'd use that." That's when I started building. DM Flow started because I needed it for my own outreach. **Build for yourself first, audience second.**

---

## Phase 1 — Write the PRD (2 hours)

This is the section most people skip. Don't. The PRD is what AI tools read to know what you actually want.

### The PRD format Claude responds well to

Copy this template into a new markdown file in your project folder:

```markdown
# [App Name] — Product Requirements Document

## What it is (1 paragraph)
[Describe the app like you're explaining it to a friend at a coffee shop. Plain language. No jargon.]

## Who it's for
- Primary user: [describe the person — age, job, problem they have]
- Use case: [when do they pull it out of their pocket?]

## The core job-to-be-done
The user opens the app to ____. They leave the app having ____.

## Must-have features (v1)
1. [Feature] — [why this is required]
2. [Feature] — [why this is required]
3. [Feature] — [why this is required]
(Keep this list to 3-5. v1 is not v2.)

## Nice-to-have features (v2+)
- [Feature]
- [Feature]
(Park future ideas here. Out of scope for v1.)

## Tech stack
- Platform: iOS (iPhone first, iPad later)
- Language: [Swift / SwiftUI native, or React Native, or Flutter]
- Storage: [Local-only? Firebase? Supabase?]
- Auth: [None for v1? Sign in with Apple?]
- Payments: [None? StoreKit IAP? Stripe?]

## Out of scope
- [Thing you will NOT build in v1]
- [Thing you will NOT build in v1]
(Be brutal. Cut features here so AI doesn't accidentally build them.)

## Success metrics
- v1 ships in [X weeks]
- [X] beta users in first month
- [X]% return rate week-over-week
```

### Filling it out — the tricks

- **Be specific in "must-have features."** "User can log a meal" is bad. "User taps `+`, types a food name, sees 5 search results from local cache in <500ms, taps one, sees a 1-line confirmation" is good. The more concrete, the less AI improvises.
- **Out-of-scope is gold.** Every feature you cut from v1 is a week of build time saved.
- **Read the PRD out loud.** If anything sounds vague, AI will hallucinate around it.

---

## Phase 2 — Pick a tech stack (15 minutes)

Three real options for non-coders. Pick one. Don't mix.

### Option A — SwiftUI native (recommended for most)
- **Best for:** Apps with iOS-specific features (HealthKit, widgets, Siri, lock screen, Apple Pay), or apps that need to feel polished.
- **Why:** Apple's own framework. AI tools (Claude, Cursor, Xcode's built-in AI) know it well. Will not feel "webby."
- **Downsides:** iOS only. Android needs a separate build.
- **Use this if:** Your app is single-platform and you want it to look native.

### Option B — React Native (recommended if you want Android too)
- **Best for:** Apps with simple UIs that need to ship on both iOS and Android from one codebase.
- **Why:** JavaScript-based. Massive AI training data. Expo CLI makes it shockingly easy.
- **Downsides:** Won't feel as native. Performance hits on animation-heavy apps.
- **Use this if:** You want to launch on both platforms with one team-of-one.

### Option C — Flutter
- **Best for:** Custom UI, smooth animations, both platforms.
- **Downsides:** Dart language has less AI training data. You'll fight Claude more often.
- **Use this if:** You specifically want the Flutter look and feel.

### Stacks to skip (as a non-coder)
- **Native UIKit (not SwiftUI):** Older Apple framework. Steeper learning curve. AI gets it wrong more often.
- **Ionic / Cordova / Capacitor:** Apps will feel like websites. App Store reviewers are quicker to reject.
- **"No-code" iOS app builders (Adalo, Glide, BuildFire):** Fine for prototypes, but you don't own the code, can't add custom features, and migration is brutal.

> 💡 **Ronnie's note:** All 3 of my apps are SwiftUI. The AI assist is the strongest there, and it ships features that feel like real iOS apps.

---

## Phase 3 — Set up your build environment (1 hour)

You need these things installed before you can build a single screen.

### Required accounts
- [ ] **Apple Developer Account** — $99/year. Sign up at [developer.apple.com](https://developer.apple.com). Takes 1–2 days to approve. **Do this first** — you cannot publish without it.
- [ ] **App Store Connect** — Comes with Apple Developer. This is where you submit builds.
- [ ] **TestFlight account** — Comes with Apple Developer. Use it to send beta builds to 100 friends without going through full review.

### Required tools
- [ ] **Mac** with macOS 14+ (you cannot build iOS apps on Windows — sorry)
- [ ] **Xcode** (free on the Mac App Store) — this is the official build tool
- [ ] **Cursor** ([cursor.com](https://cursor.com), free tier works) OR **Claude Code** (claude.ai/code) — your AI build partner
- [ ] **TestFlight app** on your iPhone (free, from App Store)

### Optional but useful
- [ ] **Figma** (free) — for sketching screens before you build them
- [ ] **GitHub account** (free) — for backing up your code
- [ ] **RevenueCat** (free up to $10K MRR) — if you're doing in-app purchases, this saves you weeks of StoreKit pain

---

## Phase 4 — The AI-assisted build workflow

This is the loop that ships features without burning you out.

### The 4-step build loop

**1. Open Cursor / Claude Code in your project folder.**

**2. Open the PRD.** Copy the entire PRD into your AI's context. Then ask:

> "Read the PRD. We're about to build feature #1 from the must-have list: [feature]. Before writing any code, write a 5-step plan for how you'd build this. Don't code yet — just the plan."

This forces the AI to think before it types. 90% of bad AI builds start because the human said "build me X" without making the AI plan first.

**3. Review the plan.** Push back on anything that:
- Adds files you don't need
- Touches code outside the feature scope
- Introduces a library not in your PRD's tech stack
- Skips the "out of scope" rule

**4. Tell the AI to execute the plan, step by step.** After each step, build and run on the Xcode Simulator. If something breaks, paste the error back to AI. Loop until the feature works on the simulator.

### Prompts that ship features

Copy-paste these. They work.

**Starting a new feature:**
> "Read [PRD.md]. Build feature [X] from the must-have list. Make a plan first. Don't add new dependencies. Don't touch code outside this feature."

**Debugging a crash:**
> "Here's the crash log from Xcode: [paste]. Tell me which line is causing it and the simplest fix. Don't refactor anything else."

**Polishing UI:**
> "Look at [Screen.swift]. The padding and font hierarchy feel off compared to Apple's HIG. Tweak it to feel native — no new colors, no new fonts, just spacing and weight."

**Preparing for the App Store:**
> "Read [PRD.md] and the current codebase. What features from the PRD are NOT done yet? What App Store rejection risks do you see? List both."

### Cadence (what shipping actually looks like)

| Week | What | Time/day |
|---|---|---|
| 1 | Build 1 screen with no logic — just look at it | 1 hour |
| 2 | Add 1 must-have feature + test it on TestFlight | 1 hour |
| 3 | Add features 2 and 3 | 1.5 hours |
| 4 | Polish, beta test with 10 friends, fix what breaks | 1 hour |
| 5 | App icon, screenshots, description, privacy policy | 2 hours total (one-time) |
| 6 | Submit to App Store | 1 hour |

**6 weeks at 1–2 hours/day = shipped app.** That's the actual math.

---

## Phase 5 — App Store submission (the part nobody warns you about)

Here's what trips up first-time submitters. Don't get caught.

### What you need before you can submit

- [ ] **App icon** (1024x1024px, no transparency, no rounded corners — Apple rounds it for you)
- [ ] **Launch screen** (built in Xcode — your PRD should specify what this looks like)
- [ ] **5–10 screenshots** per device size (iPhone 6.7" and 6.1" minimum; iPad if you support it). [Screenshots.pro](https://screenshots.pro) or [Previewed.app](https://previewed.app) make this 10x easier than building them by hand.
- [ ] **App description** (max 4000 chars, but keep it to 300 — nobody reads more)
- [ ] **Keywords** (100 chars, comma-separated, no spaces — these are how people FIND your app in App Store search)
- [ ] **Privacy policy URL** (required, even if your app collects nothing. Generate one free at [termsfeed.com](https://termsfeed.com))
- [ ] **Support URL** (can be your Twitter, your email, anything)
- [ ] **Age rating** (filled out in App Store Connect, takes 2 minutes)
- [ ] **Content rights confirmation** (just a checkbox — you confirm you own the content)

### The rejection traps

Apple rejects ~30% of first-time submissions. Here's why:

1. **"App is incomplete"** — Usually means you have a feature that crashes, or a button that doesn't work. **Fix:** before submitting, do a 30-minute "smoke test" — open every screen, tap every button. If anything's broken, fix or remove it.
2. **"Sign in required without functional reason"** — If you force sign-in and there's no clear benefit, they reject. **Fix:** either let users skip sign-in, or add "Sign in with Apple."
3. **"In-app purchase missing or wrong type"** — If your app sells anything digital, it MUST go through Apple's IAP (not Stripe). **Fix:** use StoreKit + RevenueCat.
4. **"Privacy policy doesn't match what the app does"** — They actually check. **Fix:** the privacy policy must list every piece of data you collect.
5. **"App duplicates existing functionality"** — If your app is basically a wrapper around your website, they reject. **Fix:** add at least one feature that only works as a native app (push notifications, widgets, etc.).

### Submission day checklist

```
- [ ] App icon uploaded
- [ ] Screenshots uploaded for all required device sizes
- [ ] Description & keywords entered
- [ ] Privacy policy URL works
- [ ] Support URL works
- [ ] Age rating complete
- [ ] Content rights confirmed
- [ ] Build uploaded from Xcode (Product → Archive → Distribute)
- [ ] Build assigned to a release version
- [ ] All required test devices added to TestFlight (your iPhone, beta testers)
- [ ] App tested on real device (not just simulator) — at least once
- [ ] Submit for review
```

**Expected review time: 24–72 hours.** Faster than it used to be.

---

## Phase 6 — After you ship (the actually-important phase)

Most builders treat App Store launch as the finish line. It's the starting line.

### Week 1 post-launch
- Watch reviews like a hawk. Respond to every single one.
- Check crash reports in App Store Connect daily.
- Ask 10 customers what's confusing about the app. Fix the worst one.

### Month 1 post-launch
- Decide your monetization (free with ads, freemium, subscription)
- Set up a basic Plausible / Firebase analytics flow to know if features get used
- Plan v1.1 — fix the top 3 complaints, ship in 2 weeks

### Quarter 1 post-launch
- Get to 100 active users before adding new features
- If you're not at 100, the problem is positioning/marketing, not features
- Consider Meta ads (see: Meta Ad Operator PRD in this kit) to test demand

> 💡 **Ronnie's note:** DM Flow had its first paying user in week 3 after I started actually responding to feedback in reviews. That's it. That was the whole growth tactic for the first 3 months.

---

## What to skip on v1 (seriously)

You will be tempted. Don't.

- ❌ User accounts / cloud sync (unless your PRD requires it)
- ❌ Settings screen (defer until users ask)
- ❌ Onboarding tutorial (build for users who already get it)
- ❌ Dark mode (system default works)
- ❌ Localizations (English only for v1)
- ❌ Apple Watch app
- ❌ iPad-specific layouts
- ❌ Widgets

Add these one at a time AFTER v1 ships, based on user requests.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Apple Developer Account | Required to publish | $99/year |
| Xcode | Build tool | Free |
| Cursor or Claude Code | AI build partner | $0–$20/month |
| TestFlight | Beta distribution | Free (with Apple Dev) |
| RevenueCat | IAP without pain | Free under $10K MRR |
| Figma | Sketching | Free |
| GitHub | Code backup | Free |
| Screenshot generator | App Store screenshots | $0–$15 one-time |
| Privacy policy generator | TermsFeed.com | Free |
| **Total to ship v1** | | **~$99 + your time** |

---

## Common questions

**Q: Do I need to know Swift?**
A: Helpful, not required. You need to be able to read code and tell when AI is wrong. That's a 2-week skill, not a 6-month one.

**Q: How long to ship realistically?**
A: 6–8 weeks part-time for a focused v1. Faster if you've shipped before, slower if it's your first.

**Q: What if Apple rejects?**
A: Read the rejection reason carefully. Fix it. Resubmit. Don't argue — fix and resubmit is always faster than appeal.

**Q: Should I do a paid app or free with IAP?**
A: Free with IAP, almost always. Paid apps have 90% lower install rates and you can't do a free trial.

**Q: Do I need a co-founder / engineer?**
A: No. You need a PRD, this playbook, and willingness to iterate. The 3 apps that prove this (DM Flow, CalTrackPro, Entrepreneurs Bible) had a team of one.

---

## What's next

Once your iOS app is live, the next bottleneck is getting users. That's where the **Meta Ad Operator PRD** (next in this kit) picks up. Run a $15–$35/day Meta ad straight to your App Store URL, install Apple's Search Ads attribution, and the loop closes.

You shipped. Now sell.
