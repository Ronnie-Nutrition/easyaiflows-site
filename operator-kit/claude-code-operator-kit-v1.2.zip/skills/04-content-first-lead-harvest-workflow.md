# How to Turn Social Media Engagement Into DMs That Close — The Lead Harvest Workflow

**The principle that makes outreach work: Content fills the pipeline. DMs close it.**

> *Written by Ronnie Craig — operator who switched from spreadsheet-driven cold outreach to content-driven harvest in 2026. Result: same closing rate, 10x less time, zero account bans.*

---

## What this PRD is

For years, the "outreach" playbook was: build a list, blast cold DMs, repeat. That model is dead in 2026. Platforms ban accounts that send unsolicited messages, and people don't reply to strangers.

The new model is **content-first lead harvest**:

1. You post content
2. People engage (like, comment, follow, share)
3. You harvest the engagers as fresh leads
4. You DM them with context ("hey, saw you liked my reel — wanted to say hi")
5. That conversation converts at 5–15x cold rates

This PRD teaches you the exact workflow to make content do the prospecting work for you.

## Who this is for

- You've been doing cold outreach and feeling the diminishing returns
- You post some content but aren't sure how to "convert" it to conversations
- You're a local business, coach, or solopreneur with a small but real audience
- You want a content strategy you can actually run yourself

## Outcome

After 30 days of this workflow, you'll have:
- A 2–3 post/day content cadence that's sustainable solo
- A daily harvest ritual that fills your DM queue with WARM leads
- A clear understanding of which content types generate buyer-quality engagement
- Conversations starting from a place of "I already know your work" — not "who are you?"

---

## The core principle

> **"Content fills the pipeline. DMs close it."**

Memorize that line. Put it on a sticky note.

Most operators do one or the other:
- ❌ Heavy on content, never DM the engagers → audience but no revenue
- ❌ Heavy on cold DMs, no content → outreach with zero context, low close rate

The system is **both**. Post → engage → harvest → DM. Every day.

---

## Phase 1 — The content cadence that fills the pipeline

You don't need to be a "content creator" to make this work. You need a **repeatable cadence** that produces SOMETHING daily.

### The minimum viable cadence

| Day | Post type | Channel |
|---|---|---|
| Mon | Behind-the-scenes / story | IG Story, FB Story |
| Tue | Customer transformation / testimonial | IG Reel, TikTok |
| Wed | Educational tip / how-to | IG Carousel, FB Post |
| Thu | Product / service feature | IG Reel, TikTok |
| Fri | Community / fun / personality | IG Story, TikTok |
| Sat | Re-post a top performer from this week | Anywhere |
| Sun | Off |

Total: 6 posts/week, each takes 10–20 min. Sustainable solo.

### What "good" content looks like for harvest

The goal of harvest-driven content is **engagement, not virality**. Engagement is what gives you names to harvest. Virality without engagement is dead weight.

- ✅ **Posts that invite a question or DM** ("Comment 'INFO' and I'll send you the details")
- ✅ **Real, raw, phone-shot** (algorithms reward casual over polished now)
- ✅ **Local context** if you're a local biz ("Pearland folks — you tried this yet?")
- ✅ **Specific results with numbers** ("She went from 8.0 to 6.0 A1C in 4 months")

Skip:
- ❌ Pure aesthetic / brand mood boards (zero engagement)
- ❌ "Inspirational quote" graphics (nobody comments on a quote)
- ❌ Stock-image carousels (the algorithm penalizes these now)

---

## Phase 2 — The daily harvest ritual

This is the muscle. 15 minutes a day. First thing in your outreach session.

### The harvest checklist

Every morning, on every platform you posted to in the last 48 hrs:

- [ ] **Open the last 2–3 posts**
- [ ] **Note new commenters** (anyone who commented in the last 24 hrs)
- [ ] **Note new likers** on viral-leaning posts (if a Reel is doing well, the likers are warm)
- [ ] **Note new followers** (past 24–48 hrs)
- [ ] **Note story repliers**
- [ ] **Note shares** (if someone shared, they're hot)

Dump them into your daily "🆕 New Leads Queue" tab in your tracker.

### What to harvest first

If you only have time for ONE harvest action, do this priority order:

1. **People who followed AND liked a post** = HOTTEST. Double signal.
2. **People who commented with a question** = HOT. They're already engaged.
3. **People who DM'd you about a post** = HOT. They started the convo.
4. **People who replied to a story** = WARM.
5. **People who just followed** = WARM-WARM.
6. **People who just liked** = WARM (lowest signal, but still warm).

### Track this metric weekly

Every Friday, count:
- How many fresh names you harvested this week
- How many turned into conversations
- How many turned into customers

Ratio you want: **harvest 50/week → 20 conversations → 3 customers.** That's a healthy ~6% close rate.

---

## Phase 3 — The "DM after harvest" mechanics

Once you have a harvested name, here's how to start the conversation in a way that converts.

### The harvest DM formula

```
[Reference what they did, specifically]
+
[Tiny piece of personal context — show you're human]
+
[Low-friction next step — a question or offer]
```

### Examples

**For a commenter on a post:**
> "Hey [name]! Just saw your comment on the [topic] post — really appreciate you chiming in. Quick one: are you in [city]? If so, first [product] is on me whenever you wanna come by."

**For a new follower from a Reel:**
> "Hey [name], thanks for the follow 👋 The Reel you came in on was about [topic] — anything specific you're working on? If [your offer] is in the wheelhouse, I'd love to send you a starter."

**For a story reply:**
> "[Reply to their reply.] Btw — if you're ever near [location], swing by. I'll set you up with one. No catch."

### Why "specific reference" matters

The first 5 words of your DM decide if they read it. "Hey, I saw you" gets ignored. "Hey, saw your comment on the chocolate smoothie post" gets read.

Specificity is the only thing that distinguishes you from a bot.

---

## Phase 4 — Closing the loop: content informed by DMs

The DMs you receive should inform your next week's content. Listen to the patterns.

### The weekly content debrief (10 min, Sunday)

- What were the TOP 3 questions people asked in DMs this week?
- Each of those is a content post next week
- What was the TOP objection ("I don't have time" / "It's too expensive" / "I tried before")?
- That's a content post that addresses the objection directly

### The compound effect

Week 1: You post 6 things. You harvest 20 leads. You have 5 conversations.
Week 4: Your content gets sharper because you're answering real questions. You harvest 50. You have 18 conversations.
Week 12: Your content does the qualifying. People DM you ready to buy. You harvest 100/week.

---

## Phase 5 — Common content failures (and the fixes)

### Failure 1: "Nobody engages with my posts"

Most likely cause: Your posts are about YOU, not about the audience.

Fix: Replace "I just launched my new [product]" with "Here's the problem [my audience] has and how we solve it." Same content, audience-first framing.

### Failure 2: "I post but get no DMs"

Most likely cause: Your posts have no call-to-DM.

Fix: End every post with a question or an invitation to DM. "Comment 'INFO' for details" or "DM me 'TRIAL' for a free one." Don't make people guess.

### Failure 3: "I'm out of content ideas"

Most likely cause: You're not listening to your DMs.

Fix: For 7 days, every DM question becomes a post. After a week you'll have a content backlog.

### Failure 4: "The same handful of people engage every time"

Most likely cause: You're posting in a vacuum.

Fix: Engage with OTHER accounts in your niche. Comment thoughtfully on 5 posts/day in your space. Their followers will discover you.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Phone camera | Content capture | Free |
| CapCut | Quick video editing | Free |
| Canva | Carousels, graphics | Free or $13/mo |
| Notion or Excel | Tracker | Free |
| **Time** | **20 min content + 15 min harvest + 60 min DMs = 95 min/day** | — |

---

## Common questions

**Q: How long until I see real revenue?**
A: 30–60 days at this cadence. Faster if your audience is already warm. Slower if you're starting from 0 followers.

**Q: Do I need a big following first?**
A: No. 500 followers running this system beats 50,000 followers with no system. Start where you are.

**Q: What if my content flops?**
A: Run 3 posts per format (Reel, Carousel, Story) over 2 weeks. The patterns will show you which to lean into. Don't judge a single post.

**Q: Should I run ads to my content?**
A: Yes — once you have ONE post that's organically performing above your norm. Boost that one for $5–10/day to extend the harvest pool. (See: Meta Ad Operator PRD.)

---

## What's next

This system feeds your DM queue. The DM queue needs the **100-Conversation Daily Outreach System** (skill #3) to be processed daily, and the **2-Strike + Dead Lead Rule** (skill #5) to keep it clean.

Together: content → harvest → DM → close. That's the whole engine.
