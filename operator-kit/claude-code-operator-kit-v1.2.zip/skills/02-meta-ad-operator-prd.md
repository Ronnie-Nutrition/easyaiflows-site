# How to Run a Profitable Meta Ad in 2026 — Pixel + CAPI + Optimization Playbook

**The non-marketer's playbook for running a profitable Meta ad — without wasting your money on agency theory.**

> *Written by Ronnie Craig — operator running a $35/day workhorse ad with 4.49% CTR, $0.16 CPC, and a working Pixel + Conversions API setup. This is the exact build I use.*

---

## What this PRD is

Meta ads is the #1 way small business operators waste money on the internet. Not because the platform is broken — because nobody teaches them the actual mechanical setup. You boost a post, you "promote your business," you let Meta's "Advantage+" pick everything for you, and 30 days later you've spent $500 with nothing to show for it.

This PRD teaches you the **operator's mechanical setup** for a Meta ad that actually optimizes against a real signal. You'll learn:

1. The 4 things that have to be true before a single dollar gets spent
2. How to install the Meta Pixel + Conversions API (server-side) so Meta sees real conversions
3. Which optimization event to pick (this is where 90% of beginners get it wrong)
4. How to audit a live ad and kill the zombie campaigns silently bleeding your account
5. The exact ad config that's working for me right now

## Who this is for

- You own or run a local business, e-commerce store, lead-gen funnel, or app
- You've tried Meta ads before and got nothing
- You're done with agencies promising results they can't measure
- You want a system you can run yourself for $15–$50/day

## Outcome

By the end of this playbook, you have:
- A clean Meta account with Pixel + CAPI installed and verified
- A live ad optimizing against a real conversion event
- A weekly audit habit so spend doesn't drift
- The confidence to scale or kill ads based on data, not vibes

---

## Phase 0 — Before you spend $1

### The 4 prerequisites

If any of these aren't true, do not run an ad. You will set money on fire.

1. **You have a destination URL that converts.** Whether it's a landing page, order site, or App Store URL — someone unfamiliar with you can land on it and figure out the next step in under 5 seconds. Test it on your mom.
2. **You have the Meta Pixel installed and firing.** Open your site in Chrome with the [Meta Pixel Helper extension](https://chromewebstore.google.com/detail/meta-pixel-helper/) on. You should see at least `PageView` fire when the page loads. If you don't, **stop and install the pixel first.** (See Phase 1 below.)
3. **You have the Conversions API (CAPI) installed.** Browser-only pixel is half-blind in 2026 — iOS 14.5+ blocks a huge chunk of tracking. CAPI is the server-side backup. (See Phase 2.)
4. **You can name the ONE action you want a buyer to take.** "Click my ad" is wrong. "Add to cart" / "Sign up" / "Schedule a call" — pick one, write it down.

If you can't check all 4 boxes, the rest of this PRD is premature.

---

## Phase 1 — Install the Meta Pixel (browser-side)

This is the JavaScript snippet that fires when someone visits your site.

### Get your Pixel ID

1. Go to [business.facebook.com](https://business.facebook.com) → Events Manager
2. Click "Connect Data Sources" → "Web" → "Meta Pixel"
3. Name it after your business (e.g., "Nutrition Hub Pixel")
4. Save the 15-digit Pixel ID it gives you

### Install the snippet (every page on your site)

Paste this in the `<head>` of every page (or your global template):

```html
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){
if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', 'YOUR_PIXEL_ID_HERE');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=YOUR_PIXEL_ID_HERE&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
```

### Fire conversion events on the right pages

Don't fire only PageView. Fire actual conversion events on conversion-y pages:

| Page | Event to fire |
|---|---|
| Product / pricing | `ViewContent` |
| Add-to-cart click | `AddToCart` |
| Checkout / payment step | `InitiateCheckout` |
| Order confirmation | `Purchase` (with value + currency) |
| Lead form submitted | `Lead` |
| Signup completed | `CompleteRegistration` |

Example for a Purchase event on your order confirmation page:

```html
<script>
fbq('track', 'Purchase', {
  value: 24.97,
  currency: 'USD',
  content_ids: ['operator-kit'],
  content_type: 'product'
});
</script>
```

### Verify it works

1. Install the [Meta Pixel Helper Chrome extension](https://chromewebstore.google.com/detail/meta-pixel-helper/).
2. Visit your site in an **incognito window**. The extension icon should light up green.
3. Click the `</>` icon — you should see `PageView` firing.
4. **Click "Show all events"** in the popup. The summary view hides custom events by default — if you skip this step you'll think your custom events aren't firing when they actually are.
5. Walk through a fake purchase — you should see your conversion events fire in order.

> ⚠️ **The most common mistake:** Firing `InitiateCheckout` on the *button click* that leaves your landing page (not on the actual checkout step). This inflates your event count with fake checkouts. Fix: fire `AddToCart` on the outbound button (for OUTCOME_SALES campaigns) or `Lead` (for OUTCOME_LEADS campaigns). Save `InitiateCheckout` for the real cart/payment step.

> ⚠️ **"Automatic Website Matching" noise:** if you have Meta's auto-detection on, Pixel Helper may show extra events like `SubscribeButtonClick` next to your real events. These are Meta's algorithm guessing at button intent — duplicate signal, not harmful, but cluttering your data. Either ignore them or turn off "Automatic website matching" in Events Manager → Pixel → Settings.

---

## Phase 1B — When your checkout lives on a third-party platform

Most operators selling digital products don't run their own checkout. They use Gumroad, Stripe Checkout, Shopify, Kajabi, ConvertKit, etc. — third-party platforms hosted on different domains.

**You can't paste Meta Pixel code on someone else's domain.** So you need a different pattern:

| Layer | Where it lives | What it fires |
|---|---|---|
| Your landing page | Your domain | `PageView`, `ViewContent`, `AddToCart` (on outbound button click) |
| Third-party checkout | Their domain | `InitiateCheckout`, `Purchase` — via their built-in Meta Pixel integration |

### How to wire a third-party platform (Gumroad example)

1. **In Gumroad:** Settings → Advanced → Third-party analytics → paste your Pixel ID → enable Purchase events → Save
2. **On your landing page:** fire `AddToCart` on the outbound click that sends people to Gumroad:
   ```html
   <a href="https://yourshop.gumroad.com/l/your-product" data-pixel="atc">Buy Now</a>
   <script>
   document.querySelectorAll('a[data-pixel="atc"]').forEach(function(el){
     el.addEventListener('click', function(){
       fbq('track', 'AddToCart', {value: 24.97, currency: 'USD'});
     });
   });
   </script>
   ```
3. **Verify in Pixel Helper:** visit your landing page → events show `PageView`, `ViewContent`, `AddToCart`. Visit the Gumroad page directly → events show `ViewContent` (Gumroad's pixel integration is working). After a real purchase → `Purchase` shows in Events Manager → Overview within 30 min.

Same pattern applies to Shopify (Settings → Online Store → Preferences → Facebook Pixel), Stripe Checkout (Account → Tax & business → integrations), Kajabi (Settings → Tracking & Analytics), etc.

> ⚠️ **No Conversions API for your landing page in this setup.** Browser-only pixel means iOS 14.5+ users may not register `AddToCart` events. That's OK — the third-party platform's Purchase fire IS server-side and IS the actual conversion signal you care about. AddToCart is just early optimization signal.

---

## Phase 2 — Install Conversions API (server-side)

Browser pixel alone is ~60% accurate in 2026. CAPI brings it to ~95%. **Do not skip this.**

### Get a CAPI access token

1. Events Manager → your Pixel → Settings → Conversions API → "Generate access token"
2. Copy and save it as an environment variable: `META_CAPI_TOKEN=...`
3. You'll also need your Pixel ID: `META_PIXEL_ID=...`

### Node.js implementation (works on any Node server)

This is the exact pattern I run in production. Paste this into your Node server file:

```javascript
const https = require('https');
const crypto = require('crypto');

const META_PIXEL_ID = process.env.META_PIXEL_ID;
const META_CAPI_TOKEN = process.env.META_CAPI_TOKEN;

function sha256Hash(str) {
  return crypto.createHash('sha256').update(String(str).trim().toLowerCase()).digest('hex');
}

function sendMetaCapiPurchase(order, chargeId, req) {
  if (!META_CAPI_TOKEN) {
    console.log('[CAPI] META_CAPI_TOKEN not set, skipping');
    return;
  }

  const eventId = `purchase_${chargeId}`; // SAME as browser pixel — for dedup
  const ip = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.connection.remoteAddress;
  const userAgent = req.headers['user-agent'] || '';
  const fbc = req.cookies?._fbc || '';
  const fbp = req.cookies?._fbp || '';

  const payload = {
    data: [{
      event_name: 'Purchase',
      event_time: Math.floor(Date.now() / 1000),
      event_id: eventId,
      action_source: 'website',
      event_source_url: `https://yourdomain.com/order-complete`,
      user_data: {
        em: order.email ? [sha256Hash(order.email)] : undefined,
        ph: order.phone ? [sha256Hash(order.phone.replace(/\D/g, ''))] : undefined,
        client_ip_address: ip,
        client_user_agent: userAgent,
        fbc: fbc || undefined,
        fbp: fbp || undefined,
      },
      custom_data: {
        currency: 'USD',
        value: order.total,
        content_ids: order.items.map(i => i.sku),
        content_type: 'product',
      },
    }],
  };

  const data = JSON.stringify(payload);
  const options = {
    hostname: 'graph.facebook.com',
    port: 443,
    path: `/v19.0/${META_PIXEL_ID}/events?access_token=${encodeURIComponent(META_CAPI_TOKEN)}`,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length,
    },
  };

  const r = https.request(options, (res) => {
    let chunks = '';
    res.on('data', (c) => (chunks += c));
    res.on('end', () => console.log(`[CAPI] Purchase sent: ${chunks.slice(0, 120)}`));
  });
  r.on('error', (e) => console.error('[CAPI] error:', e.message));
  r.write(data);
  r.end();
}
```

### The dedup trick (critical)

When you fire `Purchase` both browser-side AND server-side, you get **double-counted events** unless you dedup.

The dedup key is `event_id`. Generate the SAME unique ID in both places (e.g., `purchase_${stripe_charge_id}`) and Meta will collapse them into one. Without this, your reports lie.

In your browser pixel:

```javascript
const eventId = `purchase_${chargeId}`;
fbq('track', 'Purchase', {
  value: order.total,
  currency: 'USD',
}, { eventID: eventId });  // ← same eventID as CAPI
```

### Verify CAPI works

1. Events Manager → your Pixel → Test Events tab → generate a test code
2. Set `META_CAPI_TEST_CODE` env var on your server temporarily
3. Trigger a real purchase from your site
4. You should see TWO matching events in the Test Events tab (one browser, one server) — and they should auto-dedupe

---

## Phase 3 — Pick the right optimization event

This is where almost everyone gets it wrong. The optimization event tells Meta what action to find people who'll take.

### The rule

**Optimize for the EARLIEST event in your funnel that gets 50+ conversions per week.**

The right event also depends on your campaign **objective**. Meta's interface forces you to pick: OUTCOME_SALES (for product purchases) or OUTCOME_LEADS (for service signups). The valid optimization events differ.

### For OUTCOME_SALES campaigns (e-commerce, digital products, app installs with purchase)

| Weekly purchases | Optimize for |
|---|---|
| 0–10 | `AddToCart` (NOT Lead — Meta rejects Lead for sales objective) |
| 10–50 | `InitiateCheckout` |
| 50+ | `Purchase` ← the holy grail |

### For OUTCOME_LEADS campaigns (services, consultations, gated content, B2B SaaS)

| Weekly leads | Optimize for |
|---|---|
| 0–10 | `ViewContent` (or `CompleteRegistration` if your quiz/form is broken into steps) |
| 10–50 | `Lead` |
| 50+ | `Lead` (with quality filters layered) |

If you optimize for `Purchase` when you only get 2 a week, Meta has no learning data. It will deliver to random people because it doesn't know what works.

> 🚨 **The OUTCOME_SALES vs OUTCOME_LEADS gotcha:** Meta's API will reject `LEAD` as the optimization event for an OUTCOME_SALES campaign with the error *"This conversion event isn't available with the objective you selected."* If you're selling a product (even a $20 digital one), use `AddToCart` — not `Lead` — as your low-volume optimization event.

### How to set it in Ads Manager

When creating your ad set:
- **Conversion location:** Website
- **Performance goal / Optimization goal:** Maximize number of conversions
- **Conversion event:** Pick your event from the table above

### How to verify in the API

The adset's `promoted_object` should look like:

```json
{
  "pixel_id": "915336731481586",
  "custom_event_type": "ADD_TO_CART"
}
```

If that's missing or set to the wrong event, your ad is broken even if it looks fine in the dashboard.

> ⚠️ **Once an ad set is published, the optimization event is locked.** Meta returns *"You can't edit your pixel, conversion event, custom conversion or optimization for an ad set after the ad set is published."* If you need to change it, create a new ad set in the same campaign and delete the old one.

---

## Phase 4 — Build a working ad (the exact config)

This is the workhorse config I use. Copy it.

### Campaign settings

| Setting | Value |
|---|---|
| **Buying type** | Auction |
| **Campaign objective** | Sales (OUTCOME_SALES) |
| **Special ad category** | None (unless you're in housing/credit/employment) |
| **Budget** | Campaign-level, $25–$35/day to start |
| **A/B test** | Off (for v1) |
| **Advantage campaign budget** | On |

### Ad set settings

| Setting | Value |
|---|---|
| **Conversion location** | Website |
| **Performance goal** | Maximize number of conversions |
| **Conversion event** | InitiateCheckout (or whichever passes the 50/week rule) |
| **Schedule** | Run continuously |
| **Audience** | Custom Audience (existing customers' lookalike) OR location-based (e.g., 5–25 mi from store) |
| **Age** | 18–65 |
| **Gender** | All |
| **Languages** | English |
| **Placements** | Advantage+ (let Meta pick) |

### Ad-level settings

| Setting | Value |
|---|---|
| **Ad format** | Single image or single video — NOT carousel for v1 |
| **Primary text** | 3-line max. First line is a benefit + a number. |
| **Headline** | Outcome + curiosity hook (under 40 chars) |
| **Description** | (optional, often gets cut) |
| **Call to action** | "Order Now" / "Shop Now" / "Learn More" / "Sign Up" |
| **Destination URL** | The page that fires your optimization event |
| **URL parameters** | `utm_source=meta&utm_medium=cpc&utm_campaign={{campaign.name}}&utm_content={{ad.id}}` |

### Creative that actually works

For local business:
- ✅ Real product photo (your actual smoothie, taco, haircut)
- ✅ Phone-shot, not stock
- ✅ Price visible if it's competitive ("$10")
- ✅ Local landmark / city name in copy

For SaaS / digital:
- ✅ Screenshot of the actual product, not a 3D mockup
- ✅ A specific result ("from 0 to 100 leads in 30 days")
- ✅ Founder face in the video — people buy from people

Skip:
- ❌ Stock photos (Meta penalizes them in ranking)
- ❌ Long videos (3 seconds or you lose them)
- ❌ Sales-y "ONLY $9.99!!!!" copy (auto-rejected by Meta's quality ranker)

---

## Phase 4B — Pre-launch checklist

Before you click that ACTIVE toggle, run through this list. Each item saves a category of mistake that's easy to make and hard to detect after the fact.

| ✓ | Check | How to verify |
|---|---|---|
| ☐ | **Pixel base code installed on landing page** | `view-source:yourdomain.com/yourpage` should contain your Pixel ID |
| ☐ | **PageView, ViewContent fire on page load** | Pixel Helper → "Show all events" (NOT the summary view) → both show "Active" |
| ☐ | **AddToCart fires on buy button click** | Pixel Helper → click buy button → re-check → AddToCart now visible |
| ☐ | **Third-party platform pixel integration wired** (if using Gumroad/Shopify/etc.) | Visit the checkout page directly → Pixel Helper shows your pixel firing on their domain |
| ☐ | **Domain verified in Meta Business Suite** | Business Settings → Brand Safety → Domains → your domain shows green "Verified" |
| ☐ | **Optimization event matches the funnel stage rule** | Adset's `promoted_object.custom_event_type` matches the table above |
| ☐ | **Seed Meta with 1 conversion event before launch** | In incognito, click your buy button once. This fires 1 AddToCart, which clears the "No conversion activity in this dataset" warning and lets Meta start optimizing on day 1 instead of day 3 |
| ☐ | **Advantage+ creative enhancements that REWRITE your work are OFF** | Ad-level → Advantage+ creative → turn off `text_optimizations` and `video_filtering`. Leave `enhance_cta` on (harmless polish) |
| ☐ | **CAPI installed** OR third-party Purchase event flowing | Events Manager → Test Events → trigger a real purchase → see both browser + server (or platform-side) Purchase event arrive |

> 🟢 **About AEM (Aggregated Event Measurement):** for web pixels created in 2026+, Meta auto-manages the event priority list. There are no user-facing controls in either UI or API. You can stop hunting for it. Per Meta's Help panel: *"There are no actions that you need to take."*

---

## Phase 5 — Audit your account weekly

A live ad without a weekly audit drifts in 2 weeks. Here's the 15-minute audit I run every Monday.

### The 15-minute weekly audit

**1. Check zombie campaigns.**

Open Ads Manager → Campaigns view. Filter to "Active" status. Look for any campaign with:
- 0 active ad sets, OR
- 0 active ads, OR
- $0 spend in the last 30 days

These are zombies. Pause them. They clutter your view and can rarely "accidentally" start spending if a teammate flips a switch.

**2. Verify your optimization event still fires.**

Events Manager → your Pixel → Overview. Look at the last 7 days. Your optimization event should be the #1 or #2 most-fired event. If it's 5th and below, your ad is optimizing against a signal Meta barely sees — pause and rethink.

**3. Check pixel + CAPI dedup.**

Events Manager → Test Events. Run a fake purchase. You should see both browser + server events showing as deduped. If you see them as separate events, your `event_id` matching is broken.

**4. Spend efficiency check.**

For each active ad, compute: `(spend last 7d) / (purchases last 7d) = effective CPA`.
- If effective CPA is at or below your target → keep it running, consider scaling
- If 2x your target → kill the ad, save the budget
- If between → wait one more week before judging

**5. Inflation check.**

If your `InitiateCheckout` count is >5x your `AddToCart` count, something is firing IC events without a real cart. This usually means a button is firing IC on click instead of on the real cart step. Fix the code, don't just live with it.

---

## Phase 6 — Scale only after these 3 things are true

Don't scale spend until:

1. **CPA is at or below your max acceptable CPA for 14 consecutive days.** Not 7 — that's still noise.
2. **Your conversion event fires 50+ times per week.** Below that, Meta can't optimize at scale either.
3. **You have a backup ad ready.** When you scale, your current ad will fatigue. Have ad #2 lined up.

### How to scale safely

- **Vertical scale:** Increase daily budget 20% every 3 days. More than 20% kicks the ad back to learning phase.
- **Horizontal scale:** Duplicate the ad set into a new audience (different city, different lookalike %, etc.). Don't add more audiences to the same ad set — Meta won't split test them well.

---

## Common questions

**Q: Should I use Advantage+ Shopping campaigns?**
A: For e-commerce with 50+ purchases/week, yes. Below that, manual conversion campaigns give you more control.

**Q: How long should I let an ad run before judging?**
A: Minimum 3 days, ideal 7 days. Anything less is noise.

**Q: My CTR is 5%+ but no purchases. What's wrong?**
A: Your ad attracts attention but your landing page doesn't convert. Audit the landing page, not the ad.

**Q: My CTR is 0.5%. What's wrong?**
A: The ad creative is the problem. Test a new image/video. The audience is rarely the issue at low CTR.

**Q: When should I pause vs. let it ride?**
A: Pause if spend > 3x your CPA target with zero conversions. Otherwise, give it 7 days.

**Q: Do I need a video?**
A: Not for v1. A single sharp photo can outperform a mediocre video. Start with a photo, test a video later.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Meta Business Manager | Required to run ads | Free |
| Meta Pixel | Browser tracking | Free |
| Meta Conversions API | Server tracking | Free (API access) |
| Meta Pixel Helper (Chrome) | Verify pixel fires | Free |
| Canva | Ad creative | Free or $13/mo |
| **Test budget to validate setup** | | **$10/day × 7 days = $70** |
| **Workhorse budget after validation** | | **$25–$50/day** |

---

## What's next

Once your Meta ad is profitable, the next bottleneck is the rest of your funnel — outreach to people who clicked but didn't convert, your loyalty system for repeat customers, your content engine that fills the pipeline.

That's where the rest of this kit takes over:
- **100-Conversation Daily Outreach System** (skill #3)
- **Content-First Lead Harvest** (skill #4)
- **Custom Audience Builder** (skill #10)
- **Live Ad Audit + Zombie Sweep** (skill #11 — the exact audit ritual)

You built a profitable ad. Now keep it profitable.

---

## Appendix — Meta Marketing API gotchas

If you're building campaigns programmatically via the Graph API (instead of clicking through Ads Manager), expect these traps. Each one cost me real time the first time I hit it.

### Campaign-level gotchas

- **Bid strategy auto-defaults to `LOWEST_COST_WITH_BID_CAP`** when you create a campaign without specifying one. Then the adset creation fails with *"Bid amount required for the bid strategy provided."* Fix: explicitly set `bid_strategy: LOWEST_COST_WITHOUT_CAP` on campaign create, or PATCH it before creating the adset.
- **Buying type defaults to AUCTION** — correct, leave it.
- **special_ad_categories must be sent as a JSON array `[]`** for normal commerce. Sending an empty string fails silently.

### Ad set-level gotchas

- **Optimization event naming uses past tense:** `INITIATED_CHECKOUT` (not `INITIATE_CHECKOUT`). Same for `COMPLETE_REGISTRATION`. The Pixel fires event names in PascalCase (`InitiateCheckout`) but the API's `promoted_object.custom_event_type` uses SCREAMING_PAST_TENSE (`INITIATED_CHECKOUT`).
- **`LEAD` is rejected for OUTCOME_SALES campaigns.** Use `ADD_TO_CART` instead. (See Phase 3 above for the full mapping.)
- **`facebook_video_feeds` is deprecated.** Don't include it in `facebook_positions` or the adset rejects with *"Facebook video feeds placement is deprecated."*
- **Advantage+ Audience forces `age_max ≥ 65`.** If you try to set `age_max: 55` with `targeting_automation.advantage_audience: 1`, you get *"Maximum age is too low for Advantage+ Audience."* Either set `age_max: 65` and treat your real target age as a suggestion (Meta will honor it directionally), or turn off Advantage+ Audience entirely.
- **Once published, the pixel + optimization event + custom conversion are LOCKED.** PATCH attempts return *"Can't make edits to published ad set."* You must create a new ad set in the same campaign and delete the old one.
- **For Advantage+ placements (auto), do NOT specify `publisher_platforms`, `facebook_positions`, or `instagram_positions`.** Send the targeting object without those arrays. If you include them, you're locked into manual placements.

### Ad-level gotchas

- **Video creative requires `image_hash` or `image_url` for the thumbnail.** Even though the video has its own thumbnail, the API insists on one in `video_data`. Reuse a hash from any existing image asset in your account.
- **Returned `image_url` from a creative read is a temp signed URL** that expires. Don't try to pass it back on a new create — it'll fail with *"Your ad contains images that failed to load."* Use `image_hash` instead.
- **`effective_status: IN_PROCESS`** after creation = Meta is reviewing the creative. Normal. Usually clears in 30 min – 2 hr. Don't panic.

### A one-shot Python helper

```python
import json, os, urllib.parse, urllib.request

TOKEN = os.environ["META_ACCESS_TOKEN"]
API = "https://graph.facebook.com/v19.0"

def post(path, data):
    url = f"{API}/{path}"
    data["access_token"] = TOKEN
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body, method="POST")
    try:
        return json.loads(urllib.request.urlopen(req).read())
    except urllib.error.HTTPError as e:
        print("ERROR:", e.read().decode())
        raise

# Example: create a campaign with the right defaults out of the gate
campaign = post("act_XXXXXXX/campaigns", {
    "name": "My Sales Campaign",
    "objective": "OUTCOME_SALES",
    "status": "PAUSED",
    "special_ad_categories": json.dumps([]),
    "buying_type": "AUCTION",
    "bid_strategy": "LOWEST_COST_WITHOUT_CAP",
    "daily_budget": "1500",
})
```

Save yourself the 5 round-trips.
