# The Profitable Meta Ad Config — Field-by-Field Reference Card

**The one-page reference: what every field in a profitable Meta ad campaign should be set to — and why.**

> *Written by Ronnie Craig — operator running a workhorse ad at $35/day with these exact settings. CTR 4.49%, CPC $0.16, 55 attributed checkouts last week.*

---

## What this PRD is

You followed the full Meta Ad Operator PRD (skill #2). Pixel installed. CAPI installed. Now you need to actually build the ad — and Meta's interface has 47 buttons, half of which are misleading.

This PRD is a **field-by-field reference card** for the workhorse config. Copy these settings, change only the parts that are business-specific, and your ad will be structurally correct.

## Who this is for

- You've installed pixel + CAPI but never run a conversion campaign
- You've run ads before but suspect your settings are off
- You want a checklist, not a 40-min YouTube tutorial

## Outcome

After 30 minutes:
- A campaign / ad set / ad triplet with every field set correctly
- Optimization happening against a real signal
- A clear "if I see X metric, do Y" decision rule

---

## The 3-level structure (don't confuse these)

Meta ads have 3 nested levels. Each has DIFFERENT settings. Most beginners mix them up.

| Level | What it controls |
|---|---|
| **Campaign** | Objective, budget (if CBO), buying type |
| **Ad set** | Audience, placements, optimization event, schedule |
| **Ad** | Creative, copy, headline, destination URL, CTA |

If you put audience settings at the campaign level, the interface ignores them. If you put optimization at the ad level, same. Know the level you're on.

---

## Campaign settings

| Field | Set to | Why |
|---|---|---|
| **Campaign name** | `[Region] - [Goal] - [YYYY-MM]` (e.g., "Pearland - Conversions - 2026-05") | So you can find it later |
| **Buying type** | Auction | Reserved is for huge brands |
| **Campaign objective** | **Sales** (OUTCOME_SALES) | This is what unlocks conversion optimization |
| **Special ad category** | None — unless you're in housing, credit, employment, or politics | Special categories disable targeting features |
| **A/B test** | OFF | Turn on later once you have a winning ad to test against |
| **Advantage campaign budget (CBO)** | ON, $25–$35/day | Let Meta distribute across ad sets |
| **Campaign budget optimization** | ON | Same as above; this is the toggle |
| **Spending limit** | Optional — set if you want a max cap for the month | Safety net |
| **Status** | ACTIVE (after everything below is set) | |

### ⚠️ Common campaign mistakes

- **Picking "Traffic" objective instead of "Sales"** → Meta optimizes for clicks, not conversions. You'll get clicks, no sales.
- **Picking "Awareness" objective** → Meta optimizes for impressions. Even worse for conversions.
- **Leaving Advantage campaign budget OFF** → You'll be manually managing budgets at the ad set level, which is overkill for v1.

---

## Ad set settings

This is the most important level. Get this right or nothing else matters.

| Field | Set to | Why |
|---|---|---|
| **Ad set name** | `[Audience] - [Event optimized for]` (e.g., "Pearland 5mi - InitiateCheckout") | Audience visibility |
| **Conversion location** | Website | Not Messenger, not Calls, not App. |
| **Performance goal** | Maximize number of conversions | The "right" optimization |
| **Conversion event** | (See: optimization event picker below) | The single most important setting |
| **Cost per result goal** | Leave BLANK for v1 | Setting a target before Meta has data hurts learning |
| **Budget** | (Set at campaign level via CBO) | |
| **Schedule** | Run continuously | Don't dayparting in v1 |
| **Audience: Custom audiences** | Add your customer list / pixel-based audiences if you have them | Existing customer lookalikes convert best |
| **Audience: Geo** | 5–25 mile radius from your location (for local biz) | Local relevance > broad reach |
| **Audience: Age** | 18–65 | Don't narrow age in v1; let Meta find |
| **Audience: Gender** | All | Don't narrow gender in v1 |
| **Audience: Languages** | English (US) | Avoid multi-language in v1 |
| **Audience: Detailed targeting** | LEAVE BLANK (or 1 broad interest max) | Meta's algo does better than your targeting |
| **Advantage detailed targeting** | ON | Lets Meta expand beyond your interests if needed |
| **Placements** | **Advantage+ placements (automatic)** | Don't manually pick placements in v1 |

### The optimization event picker

The right event depends on your campaign **objective** AND your funnel stage. Meta forces you to pick OUTCOME_SALES (product purchases) or OUTCOME_LEADS (service signups) — the valid events differ.

**For OUTCOME_SALES (e-commerce, digital products, Gumroad/Shopify):**

| Weekly purchases | Pick this conversion event |
|---|---|
| 0–10 | `AddToCart` (NOT Lead — Meta rejects Lead for sales objective) |
| 10–50 | `InitiateCheckout` |
| 50+ | `Purchase` |

**For OUTCOME_LEADS (services, consultations, gated content):**

| Weekly leads | Pick this conversion event |
|---|---|
| 0–10 | `ViewContent` or `CompleteRegistration` |
| 10–50 | `Lead` |
| 50+ | `Lead` (with quality filters) |

Optimize for the EARLIEST event in your funnel that gets 50+/week. That's the rule.

> 🚨 **`LEAD` is NOT valid for OUTCOME_SALES.** Meta's API rejects it with *"This conversion event isn't available with the objective you selected."* Always use `AddToCart` as the low-volume event for a sales-objective campaign — even for cheap digital products.

### ⚠️ Common ad set mistakes

- **Optimizing for `Purchase` when you get 2/week** → Meta has no learning data. Ad will deliver randomly.
- **Picking `LEAD` for an OUTCOME_SALES campaign** → API rejects it. Use `AddToCart` instead. (Even for $20 digital products — yes, AddToCart applies.)
- **Manually picking placements (Facebook Feed only, Instagram Reels only, etc.)** → Meta's auto-placement outperforms manual 80% of the time. Let it work.
- **Including `facebook_video_feeds` in placements via API** → Deprecated. API rejects with "placement is deprecated."
- **Setting `age_max < 65` with Advantage+ Audience on via API** → API rejects with "Maximum age is too low for Advantage+ Audience." Either set 65 (and treat your real target as a suggestion) or turn off Advantage+ Audience.
- **Adding 5+ detailed targeting interests** → Over-targeting kills reach and prevents Meta's algo from finding hidden converters. 0–1 interest max in v1.
- **Setting a cost-per-result goal too aggressively** → Meta won't spend if the goal is unrealistic. Leave blank to start.
- **Trying to edit a published ad set's pixel/event** → Locked. API returns "Can't make edits to published ad set." Create a new ad set in the same campaign instead.

---

## Ad-level settings

| Field | Set to | Why |
|---|---|---|
| **Ad name** | `[Format] - [Hook] - [Date]` (e.g., "Image - $10 Protein Shakes - May 2026") | Visibility |
| **Identity: Facebook Page** | Your business page | Required |
| **Identity: Instagram account** | Link your IG business account | Allows IG placements |
| **Ad format** | Single image OR Single video | Skip carousel for v1 |
| **Media** | One photo OR one 9:16 video, 15 seconds max | Phone-shot beats stock photos |
| **Primary text** | 3 short lines, benefit-first, with a number if possible | First line decides if they read more |
| **Headline** | <40 chars, outcome + curiosity | Appears under the image |
| **Description** | Skip — often hidden | |
| **Website URL** | The page that fires your optimization event | Don't send to homepage — send to converting page |
| **URL parameters** | `utm_source=meta&utm_medium=cpc&utm_campaign={{campaign.name}}&utm_content={{ad.id}}` | UTM tagging for downstream analytics |
| **Call to action** | "Order Now" / "Shop Now" / "Learn More" / "Sign Up" | One word matters less than the destination |

### ⚠️ Common ad mistakes

- **Linking to your homepage** → Homepage has 10 distractions. Link to the page that fires your optimization event.
- **Using a video over 30 seconds** → Drop-off kills CPM. 15s is the sweet spot.
- **Stock photos** → Meta's quality ranker actively penalizes stock-looking creative.
- **Sales-y copy ("ONLY $9.99!! LIMITED TIME!!")** → Triggers Meta's low-quality content filter. Reduces delivery.

---

## What the final config looks like (workhorse)

If you set everything up right, your final state is:

```
Campaign: "Pearland - Conversions - 2026-05"
├── Objective: OUTCOME_SALES
├── Buying type: AUCTION
├── Daily budget (CBO): $35
└── Ad Set: "Pearland 5mi - InitiateCheckout"
    ├── Optimization: OFFSITE_CONVERSIONS
    ├── Promoted object: pixel=YOUR_ID, event=INITIATED_CHECKOUT
    ├── Geo: 5mi from your location
    ├── Age: 18-65, all genders
    ├── Placements: Advantage+ (auto)
    └── Ad: "Image - $10 Protein Shakes - May 2026"
        ├── Format: Single image
        ├── Creative: Phone shot of actual product
        ├── Primary: "Spring into wellness at Nutrition Hub..."
        ├── Headline: "Under $10 Protein Shakes - Order Now"
        ├── CTA: "ORDER_NOW"
        ├── URL: https://yoursite.com/order (with UTMs)
```

That's the workhorse. Memorize that shape.

---

## How to verify your config is correct (via API)

If you want to be 100% sure, hit the Meta Graph API:

```bash
curl -G \
  -d "fields=name,status,effective_status,optimization_goal,promoted_object" \
  -d "access_token=YOUR_TOKEN" \
  "https://graph.facebook.com/v19.0/YOUR_ADSET_ID"
```

You should see:
- `optimization_goal: OFFSITE_CONVERSIONS`
- `promoted_object: { pixel_id: ..., custom_event_type: ADD_TO_CART }` (or INITIATED_CHECKOUT, PURCHASE — match your funnel stage)

If `custom_event_type` is missing or set to `LINK_CLICK`, you have a misconfigured ad even if the dashboard looks normal.

### Bonus checks worth running on a fresh build

```bash
# Confirm the campaign bid_strategy didn't auto-default to BID_CAP
curl -sG "https://graph.facebook.com/v19.0/YOUR_CAMPAIGN_ID" \
  -d "fields=bid_strategy,daily_budget" \
  -d "access_token=YOUR_TOKEN"
# Should return: "bid_strategy": "LOWEST_COST_WITHOUT_CAP"
# If it returns LOWEST_COST_WITH_BID_CAP, PATCH the campaign before creating the adset.

# Confirm the pixel actually fired your optimization event in the last 7 days
curl -sG "https://graph.facebook.com/v19.0/YOUR_PIXEL_ID" \
  -d "fields=id,name,last_fired_time,enable_automatic_matching" \
  -d "access_token=YOUR_TOKEN"
# last_fired_time within the last hour means the pixel is healthy
```

> 🟢 **AEM (Aggregated Event Measurement):** for 2026+ pixels, auto-managed by Meta. No user-facing config in either UI or Graph API. Stop hunting. Per Meta: *"There are no actions that you need to take."*

## Working with third-party checkout (Gumroad, Shopify, Stripe Checkout, Kajabi)

If your "cart" lives on someone else's domain, you can't paste pixel code there. Split the pixel responsibility:

| Layer | Where it lives | What it fires |
|---|---|---|
| Your landing page | Your domain | `PageView`, `ViewContent`, `AddToCart` (on outbound button click) |
| Third-party checkout | Their domain | `InitiateCheckout`, `Purchase` (via their pixel integration) |

**Wire-up checklist:**

1. In the platform (Gumroad / Shopify / etc.) settings → Third-party analytics → paste your Pixel ID → enable Purchase events → Save.
2. On your landing page, fire `AddToCart` on the outbound click handler.
3. Pick `AddToCart` as the adset's optimization event (until you have 50+ Purchases/week to switch to Purchase).
4. Verify both layers in Pixel Helper: your landing page should fire AddToCart; the third-party checkout page should fire ViewContent (proving their pixel integration works).

---

## Decision rules for when to change settings

| Metric you see | Decision |
|---|---|
| CTR < 1% | Creative is the problem. New image/video. |
| CTR > 2%, LPV ratio < 30% | Landing page is the problem. Audit it. |
| LPV ratio > 30%, conversion rate < 1% | Conversion page is the problem. Audit checkout flow. |
| Cost per IC > 2x target for 14 days | Pause, rebuild creative |
| Cost per IC at target for 14 days | Increase budget +20% every 3 days |
| Same CTR with 5x more spend | Audience fatigue — refresh creative |

---

## Common questions

**Q: Should I use Advantage+ Shopping campaigns instead?**
A: Only if your store does 50+ purchases/week. Below that, the standard conversion campaign gives you more control.

**Q: Should I split into 5 ad sets to test 5 audiences?**
A: Not in v1. One ad set, one audience, one ad. Add complexity later.

**Q: How long until I should change something?**
A: Minimum 7 days of data before judging. 3 days is noise.

**Q: My ad is "limited delivery." What's wrong?**
A: Usually means your conversion event isn't firing often enough for Meta's learning. Switch to an earlier funnel event (see the optimization event picker above).

---

## What's next

The workhorse config is now built. The next problem is **finding the right audience to put in the ad set**. That's where the **Custom Audience Builder for Small Biz** (skill #10) takes over.

After it's running for a week, you'll want to audit it. The **Live Ad Audit + Zombie Campaign Sweep** (skill #11) is the weekly ritual that keeps the account clean.
