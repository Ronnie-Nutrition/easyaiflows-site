# Live Ad Audit + Zombie Campaign Sweep

**The 15-minute Monday ritual that catches misconfigured ads, dead campaigns, and inflated events — before they burn your budget.**

> *Written by Ronnie Craig — operator running this audit weekly. Caught a fake `InitiateCheckout` inflation bug where my landing-page button was firing the event on outbound click — Meta was optimizing against a signal that wasn't real.*

---

## What this PRD is

A running Meta ad isn't a "set it and forget it" thing. Even when nothing seems wrong, three problems silently accumulate:

1. **Zombie campaigns** — paused or empty campaigns left as "ACTIVE" status, cluttering your view and occasionally restarting by accident
2. **Misconfigured optimization** — your pixel events drift; your optimization event count drops; Meta starts optimizing against noise
3. **Inflated events** — buttons or scripts firing the wrong pixel events, telling Meta to optimize for fake signals

This PRD gives you the 15-minute audit ritual that catches all three.

## Who this is for

- Anyone running 1+ Meta ads at $10/day or more
- Operators with 5+ campaigns in their Meta account
- People who've had ads drift in performance and don't know why
- You followed the Meta Ad Operator PRD (skill #2) and need the weekly maintenance pattern

## Outcome

After running this audit for 4 weeks:
- Account stays at ≤5 active campaigns at any time
- You catch drift within 7 days, not 30
- You know which ads to scale and which to kill, on real evidence
- Your pixel event quality stays high (real signals only)

---

## The audit, in 15 minutes

Do this every Monday morning. Set a calendar reminder.

### Minute 0–3: The active campaign sweep

**Goal:** Identify zombies and pause them.

1. Open **Ads Manager → Campaigns view**
2. Filter to **Status: Active** + **Effective Status: Active**
3. For each campaign, check:
   - Does it have ≥1 ACTIVE ad set? (If 0 → zombie)
   - Does each ACTIVE ad set have ≥1 ACTIVE ad? (If 0 → zombie)
   - Did it spend any money in the last 30 days? (If $0 and the answer to either above is no → zombie)

4. **Pause every campaign that meets ALL of:**
   - Status shows "ACTIVE"
   - 0 active adsets or 0 active ads
   - 0 spend in last 30d

The math: zombies can't spend (no active ads), but they're one toggle-flip away from spending. Clean them up.

### Minute 3–6: Verify each ACTIVE campaign's optimization event

**Goal:** Confirm Meta is optimizing for the right thing.

For each remaining ACTIVE campaign with budget:

1. Go to the AD SET inside it
2. Look for **Optimization & delivery → Performance goal** and **Conversion event**
3. Confirm:
   - **Performance goal:** "Maximize number of conversions" (NOT "Maximize link clicks" or "Maximize landing page views")
   - **Conversion event:** matches what your business actually needs (Purchase, InitiateCheckout, Lead, etc.)

### How to verify via API (more reliable than the UI):

```bash
curl -G \
  -d "fields=name,optimization_goal,promoted_object" \
  -d "access_token=YOUR_TOKEN" \
  "https://graph.facebook.com/v19.0/YOUR_ADSET_ID"
```

You should see:
```json
{
  "optimization_goal": "OFFSITE_CONVERSIONS",
  "promoted_object": {
    "pixel_id": "915336731481586",
    "custom_event_type": "INITIATED_CHECKOUT"
  }
}
```

If `optimization_goal` is `LINK_CLICKS` or `LANDING_PAGE_VIEWS` and you wanted conversions, **your ad is misconfigured.** Stop, fix, restart.

### Minute 6–10: The pixel event sanity check

**Goal:** Make sure your optimization event is firing at a reasonable rate, with no inflation.

1. Open **Events Manager → your Pixel → Overview**
2. Set date range to **last 7 days**
3. Look at the event counts. Your optimization event should rank in the top 3 most-fired events.

### The inflation check

Compare event counts. Here's the healthy ratio:

| Event | Healthy ratio |
|---|---|
| `PageView` | (baseline) |
| `ViewContent` | 10–50% of PageView |
| `AddToCart` | 10–30% of ViewContent |
| `InitiateCheckout` | 50–150% of AddToCart |
| `Purchase` | 30–80% of InitiateCheckout |

### What inflation looks like

If `InitiateCheckout` is **5x your `AddToCart`** count, something is firing IC events without a real cart action. Most common cause: a button on a landing page firing `fbq('track', 'InitiateCheckout')` on click, before the user actually starts a cart.

**Fix:** Find the button. Change the event to `Lead` or `ViewContent` instead. Real IC only fires on the actual cart/payment step.

### Minute 10–13: The campaign-level performance check

For each active campaign:

1. **Last 7 days insights:** Spend, CTR, CPC, Cost per conversion (CPA)
2. Compare to your targets:
   - **CTR > 1.5%** — healthy
   - **CPC < $1** — healthy for most small biz
   - **CPA at or below target** — keep running

### Decision rules

| What you see | Action |
|---|---|
| CTR < 1% for 7 days | New creative needed |
| CTR good, LPV ratio (LPV / clicks) < 30% | Landing page broken — audit it |
| Strong CTR, but CPA 2x+ target for 14 days | Conversion page is the problem |
| Healthy CTR + CPA hitting target | Increase budget +20% every 3 days |

### Minute 13–15: Write your decisions

Write down (Notion, sheet, whatever) for each campaign:
- What you observed
- What you changed (or didn't)
- What you're watching for next week

Future-you will thank present-you when you forget what you did 3 weeks ago.

---

## The monthly extras (every 4th audit)

Once a month, add 15 minutes for these deeper checks.

### Monthly check 1: CAPI dedup verification

In **Events Manager → Test Events**, generate a test code. Run a real purchase through your site. You should see both browser-side AND server-side Purchase events showing up, and they should **auto-dedupe** (collapse into one event in reports).

If they don't dedupe → your `event_id` matching between browser and server pixel is broken. Fix the code.

### Monthly check 2: Audience freshness

Open **Audiences**. For each custom audience:
- Last refreshed within 30 days?
- Size grew or held steady? (If shrinking, the audience is bleeding faster than it's adding — re-seed)

### Monthly check 3: Creative fatigue

For each ad in an ACTIVE campaign:
- Frequency > 3.5? Audience is seeing it too often. Refresh creative.
- CPM rising while CTR drops? Same issue. Refresh creative.

---

## The 5 most common findings (and fixes)

### Finding 1: 5+ active zombie campaigns
**Fix:** Pause all of them. Recovery: zero. Risk if left: someone (you, future you, a contractor) accidentally toggles a budget and starts spending.

### Finding 2: Optimization set to LINK_CLICKS instead of conversions
**Fix:** Recreate the ad set with the right optimization. (Meta doesn't let you change optimization goal on an existing ad set with delivery history — you have to make a new one.)

### Finding 3: Inflated InitiateCheckout
**Fix:** Find the button or script firing the fake event. Change to `Lead` or `ViewContent`. Real IC only on real cart/payment steps.

### Finding 4: Pixel not firing on the destination page
**Fix:** Install pixel snippet. Use the Meta Pixel Helper Chrome extension to verify.

### Finding 5: CAPI returning errors
**Fix:** Check your server logs. Common issues: wrong pixel ID, wrong access token, expired token, invalid event JSON.

---

## Running the audit when you have multiple businesses / accounts

If you manage ads for multiple businesses (your own + clients), run this audit:
- Once per account per week
- Standardize naming conventions so you can grep across accounts (e.g., `[YYYY-MM] [biz] - [goal]`)
- Keep a single sheet logging "last audit date" per account

---

## Common questions

**Q: Does pausing a campaign mean I lose its learning?**
A: For 30 days, the learning is preserved if you re-activate. After 30 days, Meta dumps the learning data.

**Q: Should I delete zombie campaigns instead of pausing?**
A: Pause is reversible; delete is sometimes permanent. Default to pause. Delete only if you're absolutely sure.

**Q: My CAPI events aren't deduping. Help.**
A: The `event_id` MUST be IDENTICAL between browser and server. Most common bug: browser uses `purchase_${stripeChargeId}` but server uses `${stripeChargeId}` (different prefix). Make them match exactly.

**Q: How do I know the audit is working?**
A: After 4 weeks, your CPA should be flat or improving while your spend stays steady. Drift gets caught early.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Meta Ads Manager | Audit interface | Free |
| Meta Events Manager | Pixel verification | Free |
| Meta Pixel Helper (Chrome) | Browser-side verification | Free |
| Meta Graph API | Programmatic audit | Free |
| **Time** | **15 min / week + 30 min / month** | — |

---

## What's next

The weekly audit keeps your CURRENT account clean. When you want to scale the technical infrastructure further (server-side conversion tracking, dedup, advanced matching), the **Pixel + CAPI Server-Side Install (Node)** PRD (skill #12) is the drop-in code pattern.
