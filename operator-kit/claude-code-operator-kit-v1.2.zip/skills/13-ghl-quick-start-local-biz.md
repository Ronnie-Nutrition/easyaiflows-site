# GHL Quick-Start for Local Biz

**The 30-minute Go High Level (GHL) setup that gives a local biz a working CRM, social planner, and lead capture — without paying for an "implementation consultant."**

> *Written by Ronnie Craig — operator running GHL across 2 locations for my Pearland nutrition club. This is the setup I wish I'd had on day 1 instead of stumbling through 3 months of YouTube videos.*

---

## What this PRD is

Go High Level (GHL) is the all-in-one CRM most local biz operators end up needing. Email + SMS + pipelines + social planner + booking + reporting in one tool. The problem: the GHL interface has 200+ settings and 90% of them don't matter for v1.

This PRD gives you the **minimum viable setup** to get GHL useful in 30 minutes:

1. Account structure (sub-account vs agency account)
2. The 4 essential settings to configure
3. Connecting your contacts and social accounts
4. The 3 pipelines every local biz needs

## Who this is for

- Local biz owner (1 location or multi-location)
- You signed up for GHL but never finished setting it up
- You're paying for GHL and using <10% of it
- You want a CRM you can actually use without hiring a "GHL implementer"

## Outcome

After 30 minutes:
- Working sub-account with location info, hours, custom fields
- Connected social accounts (FB, IG, Google) for the social planner
- 3 pipelines wired up (Lead → Customer, Loyalty, Reviews)
- Contacts imported from your existing list

---

## Phase 1 — Account structure (5 min)

GHL has two account types. Pick the right one.

### Agency account (1 main login, multiple sub-accounts)

Use if:
- You have multiple business locations
- You're an agency managing client accounts
- You want sub-accounts that share an agency-level template

### Sub-account / Location only

Use if:
- You have 1 location with no plan to add more
- You just want CRM features without agency complexity

### My recommendation for most operators

Start with an agency account, even if you only have 1 location. Why:
- It's the same monthly cost
- If you ever add a 2nd location or take on a client, you don't migrate
- Templates and saved emails/SMS work at the agency level

### Two-location structure

If you run 2+ locations:
- Each LOCATION = one sub-account
- Each sub-account has its own contacts, pipelines, calendar, social planner
- Agency-level dashboards roll up across all locations

---

## Phase 2 — The 4 essential settings (10 min)

For each sub-account/location, set these BEFORE anything else.

### Setting 1: Business info

**Sub-account → Settings → Business Profile**

Fill in:
- Business name (exact, matches your Google Biz)
- Address (matches Google Biz)
- Phone (matches Google Biz)
- Email
- Time zone (CRITICAL — wrong time zone breaks every scheduled message)

### Setting 2: Business hours

**Sub-account → Settings → Business Hours**

Set your actual operating hours. This affects:
- When workflows can send SMS (off-hours = held until next morning)
- When booking calendars allow appointments
- When auto-responders fire

### Setting 3: Custom fields

**Sub-account → Settings → Custom Fields**

Build the fields you'll need before importing contacts. Every operator needs at least these 6:

| Field name | Type | Purpose |
|---|---|---|
| Rewards Points | Number | For loyalty tracking |
| Total Visits | Number | Lifetime visit count |
| Last Visit Date | Date | When they came in last |
| Member Since | Date | First customer date |
| Member Status | Single line text | Active / Lapsed / Churned |
| Rewards Coupon | Single line text | Current available reward |

Save each field's **field ID** — you'll need it later for API/automation. (In GHL UI: copy from the field's settings page.)

### Setting 4: Webhook + API access

**Sub-account → Settings → API Keys**

Generate a **Private Integration Token** (called a "pit-..." token). Save it. Treat it like a password.

You'll use this for:
- Webhooks from your website / order system into GHL
- Custom integrations (Stripe, Clover, etc.)
- Programmatic contact updates

---

## Phase 3 — Connect social accounts (5 min)

**Sub-account → Social Planner → Settings → Connect Accounts**

Connect:
- Facebook Page
- Instagram Business Account (must be linked to FB Page first)
- Google Business Profile
- (Optional) LinkedIn Page, TikTok Business

### Why the social planner matters

You can now schedule posts to all connected channels from ONE interface. Saves 30+ min/day if you post daily.

### What the social planner is BAD at

- ❌ Posting to Facebook Groups (Meta API limitation, not a GHL bug)
- ❌ Native LinkedIn Article posts (only short posts/images)
- ❌ Instagram Carousels with >5 images (use IG native for these)

---

## Phase 4 — Build the 3 pipelines every local biz needs (10 min)

**Sub-account → Opportunities → Pipelines → Add Pipeline**

### Pipeline 1: Lead → Customer

Stages:
1. **New Lead** (just entered your funnel — DM, form, walk-in)
2. **Contacted** (you reached out)
3. **Replied** (they responded)
4. **Booked / Coming In** (committed to a visit)
5. **Visited** (showed up — free first visit redeemed)
6. **Customer** (made a paid purchase)

### Pipeline 2: Loyalty / Repeat

Stages:
1. **New Customer** (first paid purchase)
2. **Active** (visited within last 30 days)
3. **Lapsed** (no visit in 30–60 days — reactivation campaign target)
4. **Churned** (no visit in 60+ days)

### Pipeline 3: Reviews / Referrals

Stages:
1. **Recent Customer** (visited in last 14 days)
2. **Review Requested** (you sent the review-request workflow)
3. **Review Left** (Google/FB/Yelp review captured)
4. **Referral Asked** (you asked them to refer)
5. **Referral Sent** (they brought a friend)

---

## Phase 5 — Import contacts (5 min)

**Sub-account → Contacts → Import**

### Pre-import cleanup

Export your existing contact list (from your phone, spreadsheet, prior CRM) to a CSV with at minimum:
- First name
- Last name
- Email
- Phone (with +1 country code, no formatting — just digits)
- City, State (helps deliverability)

### Import options to check

- ✅ Skip duplicates by phone
- ✅ Tag all imported contacts with `imported_YYYY_MM` (so you can find them later if anything goes wrong)
- ✅ Don't enroll into workflows on import (manually enroll after)

### After import

- Spot-check 5 contacts to confirm fields mapped correctly
- Check Tags filter — confirm your import tag is on all the new contacts
- Run a tiny test broadcast (5 contacts) before sending to the whole list

---

## What to skip in v1

GHL has a LOT of features. Don't touch these on day 1:

- ❌ Workflows / Automations (powerful but easy to misconfigure)
- ❌ Trigger Links
- ❌ Affiliate Manager
- ❌ Communities
- ❌ Memberships
- ❌ Surveys
- ❌ Funnels (use Carrd or another lightweight builder until you outgrow it)

Master the basics first. Layer in workflows once contacts and pipelines are humming.

---

## The 3 things to do after the setup

Once GHL is configured, these 3 actions create immediate value:

### Action 1: Review-request workflow

For every new customer (Pipeline 1 → "Customer" stage), trigger an automated message 48 hours later asking for a Google review. Most operators get 0 reviews because they never ask. This automates the ask.

### Action 2: Lapsed customer reactivation

For every customer who lapses (Pipeline 2 → "Lapsed" stage), trigger a "we miss you" message with a specific offer. Reactivates a chunk of churned customers monthly.

### Action 3: Birthday automation

GHL has a built-in Birthday field. Capture it on signup. Auto-send a free-on-us birthday DM. Single highest-ROI workflow in any local biz CRM.

---

## Common questions

**Q: GHL is expensive ($97–$297/mo). Worth it for a small biz?**
A: Only if you'll actually use the CRM, social planner, AND SMS/email broadcasting. If you'll only use CRM, a cheaper tool (HubSpot Free, Pipedrive starter) is fine.

**Q: Can I migrate from another CRM into GHL?**
A: Yes — CSV export from old, import into GHL. Just make sure to map fields carefully (especially custom fields).

**Q: What about SMS deliverability / A2P registration?**
A: For US SMS, you need A2P 10DLC registration (managed by Twilio under the hood). GHL has docs. Allow 1–2 weeks for approval.

**Q: Do I need to connect every social account?**
A: No. Connect the ones you actually use. Don't waste setup time on a platform you don't post to.

**Q: Can my Virtual Assistant access GHL without seeing everything?**
A: Yes — GHL has user roles. Create a "User" role with restricted permissions for VAs.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Go High Level account | The CRM | $97–$297/month |
| **Time to set up** | **~30 min (this PRD)** | — |
| Optional: implementer | If you want it done for you | $500–$2000 one-time |

---

## What's next

GHL holds your contacts. The **Loyalty + Check-In via GHL Custom Fields** PRD (skill #14) shows how to layer a working points system on top of the custom fields you just built — without buying a separate loyalty app.
