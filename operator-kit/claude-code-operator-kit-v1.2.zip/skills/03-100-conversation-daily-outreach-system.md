# 100-Conversation Daily Outreach System

**How to have 100 real business conversations per day — without burning out, getting banned, or sounding like a bot.**

> *Written by Ronnie Craig — I run this system 5 days a week across Instagram, TikTok, Facebook, and iMessage for my Pearland nutrition club. It produces 30+ new conversations and 70+ follow-ups per day.*

---

## What this PRD is

Most "outreach" advice is theater. Send 1,000 cold DMs, ban your account, repeat. Real outreach is **100 quality conversations per day** with people who already showed signal — not a spray-and-pray.

This PRD teaches you the exact daily mix I run:

- **30 NEW conversations** (people who engaged with you today — likes, comments, follows)
- **70 FOLLOW-UPS** (people you've already talked to who haven't replied yet, or who are ready for the next touch)

That math is the whole system. Hit it 5 days a week and your pipeline never dries up.

## Who this is for

- Solo operators or small biz owners doing their own outreach
- Local businesses (gym, salon, food, services)
- Coaches / consultants who sell over DMs
- Anyone who's tried "automated outreach" and got their account banned

## Outcome

After 30 days of running this system, you'll have:
- A daily rhythm that takes ~90 minutes
- A tracker that shows you who's hot, warm, and cold
- Clean platform accounts (no bot flags)
- Real revenue from people you actually talked to

---

## The math: why 100 conversations / day

| Bucket | Daily target | Why this number |
|---|---|---|
| Instagram | 20 (hard cap) | More = bot flag. Stay AT 20, never over. |
| TikTok | 30 | TikTok is more permissive than IG; lean here for volume. |
| Facebook | 25 | Use both personal Messenger and Page inbox. |
| iMessage | 25 | Active customers + warm follow-ups only. NOT cold prospects. |
| **Total** | **100/day** | |

**Of those 100, the daily split is:**
- 30 **NEW** (today's fresh signal) — people who like/comment/follow within the last 24–48 hrs
- 70 **FOLLOW-UPS** (people from prior days who are at the next touch step)

---

## Phase 1 — The morning harvest (15 min, FIRST thing)

The FIRST thing every outreach session does is **harvest fresh engagement** from yesterday's content. This is non-negotiable.

### The harvest checklist

For each platform you posted on yesterday:

- [ ] Check the last 2–3 posts for new commenters
- [ ] Check new followers (past 24–48 hrs)
- [ ] Check story replies
- [ ] Check shares
- [ ] Add every new name to today's "New Leads Queue"

### Why harvest comes first

The lazy version of outreach is "open the spreadsheet of cold leads and message the next 10." That's how you burn through your network in 60 days.

The disciplined version is: **today's fresh engagers are 100x more likely to buy than yesterday's cold list.** Treat them like the priority they are.

> 💡 **Operator note:** If you skip the harvest and only message from your spreadsheet, the same names keep repeating in your message history. That's the signal you're running on stale leads. Harvest first, ALWAYS.

---

## Phase 2 — The 3-tier follow-up system

Every conversation lives in one of 4 buckets. Know which bucket someone's in, and the right message becomes obvious.

| Bucket | What it means | Your move |
|---|---|---|
| 🔥 **Hot** | They replied within 24 hrs, expressed interest, asked a question | Reply same day, push gently toward the next step (call, visit, purchase) |
| 🟡 **Warm** | They engaged but haven't bought yet — followed, liked, said "sounds good" | Light check-in every 4–7 days. Value-first, not sales-first. |
| 🔵 **Cold** | They haven't engaged in 14+ days | Try ONE more touch with new context (new product, event, special) |
| ❌ **Dead** | 3 unanswered messages | STOP. Mark dead. Free the slot. (See: 2-Strike + Dead Lead Rule PRD) |

### The follow-up cadence

| Touch # | Day | Message type |
|---|---|---|
| 1 | Day 0 (the day they engaged) | Personal intro, reference what they did |
| 2 | Day 3 | Value or question — never "just checking in" |
| 3 | Day 8 | New angle — different offer, different hook |
| 4 | (no touch) | If they didn't reply to 3, they're DEAD |

---

## Phase 3 — The exact messages I send

### NEW lead messages (someone who just liked/followed)

**For a fresh follow:**
> "Hey [first name], thanks for the follow! 👋 I run [your business] in [city] — happy to send you a [free thing / discount / intro offer]. Want me to set you up?"

**For a comment on your post:**
> "[Reply to their actual comment, then:] By the way, if you ever wanna try [product] in person, first one's on me. We're at [address]."

**For a story reply:**
> "[Reply to their story comment first.] If you're ever in [city], swing by — I'll set you up with one of these [products]."

### WARM lead messages (someone who replied positively but hasn't acted)

**Day 3 nudge (no pressure):**
> "Hey [name], how's [thing they mentioned] been? Just thinking about you — let me know if you're ever in the area, I'll have your [product] ready."

**Day 8 new angle:**
> "Hey [name] — quick one: we're [doing X new thing / running Y special]. Want me to save you one?"

### COLD lead final touch

**The one-shot reactivation:**
> "Hey [name], it's been a minute. Quick update — [new product / location / promo]. If it's not your thing, no worries, just wanted to share. Otherwise [next step]."

If they don't reply to that, they're DEAD. Move on.

---

## Phase 4 — The tracker (Excel or Notion)

You need a tracker. Memory is not a system. Memory is how you message the same person twice and look like a bot.

### Minimum viable tracker columns

| Column | What it holds |
|---|---|
| Name | Who |
| Platform | IG / TikTok / FB / iMessage |
| Handle / Phone | How to reach them |
| Last touch date | When you last messaged |
| Last touch # | 1, 2, or 3 (after 3 = DEAD) |
| Last reply date | When THEY last replied (blank if never) |
| Bucket | Hot / Warm / Cold / Dead / Customer |
| Notes | What they said, what they want, context |

### The Monday morning ritual

Every Monday, 10 min:
1. Sort tracker by "last touch date" ascending
2. Anyone at 3 touches with no reply → mark DEAD, archive
3. Anyone at 1–2 touches, due for next touch this week → put in the follow-up queue

That's it. No fancy CRM needed for v1.

---

## Phase 5 — The platform-specific rules that keep you un-banned

Each platform has anti-bot defenses. Break these and you lose your account.

### Instagram

- **MAX 20 NEW DMs per day.** Hard cap. Going over triggers shadow ban.
- **NEVER navigate to a profile URL directly** in the browser. Stay inside the DM inbox (`instagram.com/direct/inbox`). Use the inbox search.
- **NO copy-pasted messages.** IG's spam filter catches identical text in 2+ messages.
- **NO links in first messages.** IG hides DMs with links until the user accepts the request.

### TikTok

- ~30 DMs/day is safe.
- TikTok hides your DM unless the recipient follows you back. Lean on commenting on their content first to warm them.

### Facebook

- Personal Messenger and Business Page inbox are SEPARATE. Need separate login flows.
- Page inbox lets you message anyone who messaged the page first. Use that.

### iMessage

- iMessage is for relationship management, NOT prospecting.
- 3 buckets only: (1) active customers, (2) referral activators, (3) everyone else (leave alone)
- Mass-blasting cold iMessage = your number gets flagged as spam by Apple

---

## Phase 6 — What to do with the 100 conversations

The system only matters if conversations turn into action. Here's the conversion mechanics.

### The next-step ladder

Every reply needs ONE clear next step. Pick the right rung for the bucket:

| Bucket | Next step |
|---|---|
| 🔥 Hot reply with intent | Call / DM voice note / "come by tomorrow" |
| 🟡 Warm reply, lukewarm | "Mind if I send you a quick voice memo with the details?" |
| 🆕 New, just said hi | "Want me to set up a free [thing] for you?" |

### What NOT to do

- ❌ Send a Calendly link in the first message
- ❌ Ask "are you interested?" (the question forces a binary they'll say no to)
- ❌ Pitch in the first DM (relationship first, transaction second)
- ❌ Apologize for messaging ("sorry to bother you" lowers your perceived value)

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Excel or Notion | Tracker | Free |
| Phone (iMessage) | Outreach to iMessage bucket | Free |
| Instagram / TikTok / FB | Platform DMs | Free |
| **Time** | **90 min/day, 5 days/week** | — |

---

## Common questions

**Q: Do I really need to do this every day?**
A: 5 days a week minimum. Skip 2 days and your pipeline shows it 14 days later.

**Q: Can I outsource it?**
A: Not in v1. Your voice is the differentiator. You can hire a VA for the harvest step (filling the tracker), but YOU send the messages until you're closing $5K+/month.

**Q: Won't this annoy people?**
A: Only if you message people who didn't engage with you first. The whole system is built around contacting people who already showed signal.

**Q: What if I don't post content yet?**
A: Post first. The system runs on engagement → harvest. No content = no harvest. See the Content-First Lead Harvest PRD (next in this kit).

---

## What's next

This system depends entirely on **fresh engagement to harvest from**. If your content isn't generating likes, follows, and comments, the harvest is empty.

That's where the **Content-First Lead Harvest Workflow** (skill #4) takes over. Together they form the engine: content fills the pipeline, DMs close it.
