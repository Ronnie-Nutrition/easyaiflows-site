# Pixel + CAPI Server-Side Install (Node)

**Drop-in Node.js code for installing Meta Pixel + Conversions API with proper deduplication and Advanced Matching.**

> *Written by Ronnie Craig — this is the exact pattern running in production on order.nutritionhub101.com, recording deduped Purchase events from both browser and server.*

---

## What this PRD is

The Meta Ad Operator PRD (hero #2) covers WHY you install Pixel + CAPI. This PRD covers HOW — drop-in Node.js code you can copy-paste into your Express/Fastify/raw-http server.

You'll learn:

1. The full browser pixel snippet with proper event firing
2. The Node server-side CAPI handler
3. The dedup pattern (so events don't double-count)
4. Advanced Matching (so Meta can attribute conversions even when cookies are blocked)
5. How to verify everything works via Test Events

## Who this is for

- You have a Node.js backend (Express, Fastify, raw http, etc.)
- You handle payments yourself (Stripe, Clover, custom)
- You want server-side tracking for accuracy past iOS 14.5+ tracking restrictions
- You're comfortable editing a server file and setting environment variables

## Outcome

After this PRD:
- Pixel firing browser-side on every page
- CAPI firing server-side on Purchase
- Events deduped via `event_id`
- Advanced Matching active (hashed email, phone, IP)
- Verified in Meta Test Events

---

## Phase 1 — Browser pixel snippet (HTML)

Paste into the `<head>` of every page (or your shared template/layout file):

```html
<!-- Meta Pixel -->
<script>
!function(f,b,e,v,n,t,s){
if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');

fbq('init', 'YOUR_PIXEL_ID_HERE');
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=YOUR_PIXEL_ID_HERE&ev=PageView&noscript=1"/>
</noscript>
<!-- End Meta Pixel -->
```

Replace `YOUR_PIXEL_ID_HERE` with your real 15-digit Pixel ID from Meta Events Manager.

### Conversion events on the right pages

#### AddToCart (cart page)

```html
<script>
fbq('track', 'AddToCart', {
  value: 24.97,
  currency: 'USD',
  content_ids: ['SKU-001'],
  content_type: 'product',
});
</script>
```

#### InitiateCheckout (payment page — REAL cart step only)

```html
<script>
fbq('track', 'InitiateCheckout', {
  value: 24.97,
  currency: 'USD',
  num_items: 1,
});
</script>
```

#### Purchase (order confirmation page) — with dedup

```html
<script>
const eventId = 'purchase_' + '<%= order.chargeId %>'; // server-rendered
fbq('track', 'Purchase', {
  value: <%= order.total %>,
  currency: 'USD',
  content_ids: <%- JSON.stringify(order.items.map(i => i.sku)) %>,
  content_type: 'product',
}, { eventID: eventId });
</script>
```

⚠️ **The `eventID` parameter is critical for dedup.** It must match the `event_id` your server sends to CAPI.

---

## Phase 2 — Server-side CAPI handler (Node.js)

Paste this into your Node server file (works with Express, raw http, anything).

### Configuration

```javascript
const https = require('https');
const crypto = require('crypto');

// From Meta Events Manager → your Pixel → Settings
const META_PIXEL_ID = process.env.META_PIXEL_ID;
const META_CAPI_TOKEN = process.env.META_CAPI_TOKEN;
// Optional, for Test Events validation only
const META_CAPI_TEST_CODE = process.env.META_CAPI_TEST_CODE || '';
```

### Utility: SHA-256 hash (required for Advanced Matching)

```javascript
function sha256Hash(str) {
  return crypto.createHash('sha256')
    .update(String(str).trim().toLowerCase())
    .digest('hex');
}

function digitsOnly(str) {
  return String(str || '').replace(/\D/g, '');
}
```

### The Purchase event sender

```javascript
function sendMetaCapiPurchase(order, chargeId, req) {
  if (!META_CAPI_TOKEN) {
    console.log('[CAPI] META_CAPI_TOKEN not set — skipping');
    return;
  }

  // Use SAME eventId as browser pixel so Meta dedupes them
  const eventId = `purchase_${chargeId}`;

  // Pull client-side identifiers from request
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim()
    || req.connection.remoteAddress;
  const userAgent = req.headers['user-agent'] || '';

  // Pull _fbc and _fbp from cookies (Meta-set click IDs)
  const cookies = req.headers.cookie || '';
  const fbc = (cookies.match(/_fbc=([^;]+)/) || [])[1] || '';
  const fbp = (cookies.match(/_fbp=([^;]+)/) || [])[1] || '';

  // Build the payload
  const payload = {
    data: [{
      event_name: 'Purchase',
      event_time: Math.floor(Date.now() / 1000),
      event_id: eventId,
      action_source: 'website',
      event_source_url: `https://yourdomain.com/order-complete`,

      user_data: {
        // Hashed PII (Advanced Matching)
        em: order.email ? [sha256Hash(order.email)] : undefined,
        ph: order.phone ? [sha256Hash(digitsOnly(order.phone))] : undefined,
        fn: order.firstName ? [sha256Hash(order.firstName)] : undefined,
        ln: order.lastName ? [sha256Hash(order.lastName)] : undefined,
        ct: order.city ? [sha256Hash(order.city)] : undefined,
        st: order.state ? [sha256Hash(order.state.toLowerCase())] : undefined,
        zp: order.zip ? [sha256Hash(digitsOnly(order.zip))] : undefined,
        country: order.country ? [sha256Hash(order.country.toLowerCase())] : undefined,

        // Client-side identifiers
        client_ip_address: ip,
        client_user_agent: userAgent,
        fbc: fbc || undefined,
        fbp: fbp || undefined,
      },

      custom_data: {
        currency: 'USD',
        value: order.total,
        content_ids: order.items.map(i => i.sku),
        content_type: 'product',
        num_items: order.items.length,
      },
    }],
  };

  // Test code (for Test Events tab in Events Manager)
  if (META_CAPI_TEST_CODE) {
    payload.test_event_code = META_CAPI_TEST_CODE;
  }

  const data = JSON.stringify(payload);
  const options = {
    hostname: 'graph.facebook.com',
    port: 443,
    path: `/v19.0/${META_PIXEL_ID}/events?access_token=${encodeURIComponent(META_CAPI_TOKEN)}`,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length,
    },
  };

  const r = https.request(options, (res) => {
    let chunks = '';
    res.on('data', (c) => (chunks += c));
    res.on('end', () => {
      console.log(`[CAPI] Purchase sent (event_id=${eventId}, value=$${order.total}): ${chunks.slice(0, 200)}`);
    });
  });

  r.on('error', (e) => console.error('[CAPI] error:', e.message));
  r.write(data);
  r.end();
}
```

### Where to call it

In your order completion handler — AFTER the payment succeeds:

```javascript
// In your /charge or /checkout-complete endpoint
async function handleOrderComplete(req, res) {
  // 1. Process payment (Stripe, Clover, whatever)
  const charge = await processPayment(req.body);

  if (!charge.success) {
    return res.status(400).json({ error: 'Payment failed' });
  }

  // 2. Save order to DB
  const order = await saveOrder(charge);

  // 3. Send confirmation email
  await sendOrderEmail(order);

  // 4. Fire server-side CAPI Purchase event (deduped with browser)
  sendMetaCapiPurchase(order, charge.id, req);

  // 5. Respond to client (which will fire browser pixel)
  res.json({
    success: true,
    chargeId: charge.id, // browser will use this for its eventId
    orderId: order.id,
  });
}
```

The client-side success handler then uses the returned `chargeId` to fire the browser pixel with the matching `eventID`. Dedup achieved.

---

## Phase 3 — Other server-side events

Purchase is the most important, but you can send CAPI for any conversion event.

### Lead (from email signup, contact form, etc.)

```javascript
function sendMetaCapiLead(email, req) {
  if (!META_CAPI_TOKEN) return;

  const eventId = `lead_${crypto.randomUUID()}`;
  // ... same structure as Purchase, but:
  // event_name: 'Lead'
  // custom_data: { content_name: 'newsletter_signup', value: 0, currency: 'USD' }
}
```

### CompleteRegistration (from new account creation)

```javascript
function sendMetaCapiRegistration(user, req) {
  // event_name: 'CompleteRegistration'
  // custom_data: { content_name: 'account_signup', value: 0, currency: 'USD' }
}
```

The pattern is identical — what changes is `event_name`, `custom_data`, and the `event_id` prefix.

---

## Phase 4 — Verify in Test Events

Before going live, verify the dedup is working.

### Step 1: Generate a test code

1. **Meta Events Manager → your Pixel → Test Events tab**
2. Copy the test code (something like `TEST12345`)

### Step 2: Set it on your server

```bash
export META_CAPI_TEST_CODE=TEST12345
node server.js
```

### Step 3: Run a real test purchase

1. Open your site in a browser (with Pixel Helper extension on)
2. Add to cart → checkout → complete a real or test purchase
3. Watch the Test Events tab in Events Manager — you should see **two events** appear:
   - One from "Browser" with your `event_id`
   - One from "Server" with the same `event_id`
4. Within ~5 minutes, Meta should **dedupe** them — collapse into one event

### Step 4: Unset the test code

Once verified, remove `META_CAPI_TEST_CODE` from your env vars. Live Purchases will now flow as normal events.

```bash
unset META_CAPI_TEST_CODE
# or remove the line from your .env
```

---

## Common pitfalls

### Pitfall 1: Event IDs don't match
The most common bug. Browser fires `purchase_abc123` but server sends `abc123` (no prefix). Meta sees them as separate events.

**Fix:** Make them IDENTICAL. Decide on a format (e.g., `purchase_${stripeChargeId}`) and use it both places.

### Pitfall 2: Server fires CAPI before payment confirms
You call `sendMetaCapiPurchase` before knowing the payment actually succeeded. Now you report fake purchases.

**Fix:** Only fire CAPI AFTER `charge.success === true`.

### Pitfall 3: Personal data sent unhashed
You send `em: order.email` (raw email) instead of `em: [sha256Hash(order.email)]`. Meta rejects the event.

**Fix:** ALWAYS hash PII before sending. Use SHA-256, lowercase, trim whitespace.

### Pitfall 4: Test code left in production
You forget to remove `META_CAPI_TEST_CODE` and your live events go to the Test Events tab instead of production. Ads don't optimize.

**Fix:** Remove the env var after testing. Add a check on server boot.

### Pitfall 5: Missing client_ip_address
You forget to extract IP from the request. Meta has lower attribution accuracy without it.

**Fix:** Always pass `client_ip_address` and `client_user_agent` in `user_data`.

---

## Common questions

**Q: Do I need CAPI if I have the browser pixel?**
A: Yes. iOS 14.5+ and ad-blockers strip ~30–40% of browser events. CAPI catches the missing ones.

**Q: Does CAPI replace the browser pixel?**
A: No — they work together. Browser captures user-facing signals (clicks, page views). CAPI captures server-confirmed events (purchases). Dedup keeps them clean.

**Q: What if my server isn't Node?**
A: The pattern is the same in any language. Hash PII, build the payload, POST to `graph.facebook.com/v19.0/{pixel_id}/events`. Python, PHP, Ruby — all the same shape.

**Q: How long until CAPI events show up in reports?**
A: Test Events: within 30 sec. Production Events Manager: 1–24 hours.

**Q: What if I'm using a no-code platform (Shopify, WordPress)?**
A: They usually have a Meta integration that handles browser pixel automatically. For CAPI, you need an app/plugin (Shopify has a native one).

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Meta Events Manager | Pixel ID + CAPI token | Free |
| Node.js server | Hosting the CAPI handler | Your existing infra |
| Meta Pixel Helper (Chrome) | Browser-side verification | Free |
| **Time to implement** | **2–3 hours one-time** | — |

---

## What's next

You now have full-stack tracking. Next: keeping the account clean weekly with the **Live Ad Audit + Zombie Campaign Sweep** (skill #11), and managing customer data with the **GHL Quick-Start** (skill #13).
