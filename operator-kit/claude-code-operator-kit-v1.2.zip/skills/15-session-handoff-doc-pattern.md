# Claude Code Memory Hack: The Session Handoff Doc That Saves Your Context

**The one habit that lets you pick up exactly where you left off in Claude Code — across days, weeks, and project pauses.**

> *Written by Ronnie Craig — I write a handoff doc at the end of every Claude Code session. The result: I never start a new session lost, and every project compounds instead of resetting.*

---

## What this PRD is

If you've used Claude Code (or any AI coding assistant) for more than a week, you've hit this wall: **next session, the AI doesn't remember anything.** You start over. You re-explain. You waste 20 minutes catching the AI up.

The fix isn't a smarter AI. It's a simple, repeatable habit: **end every session with a handoff doc.**

This PRD teaches you the exact handoff doc structure I use, and how to make Claude write it for you in 60 seconds before you close the session.

## Who this is for

- Claude Code (or any AI coding tool) users with multi-session projects
- Solo operators / non-coders shipping software with AI help
- Anyone who's frustrated by "AI forgets" and has been working around it badly

## Outcome

After running this pattern for 2 weeks:
- You can resume any project in 90 seconds (vs. 20 min)
- You can pause projects for weeks and resume without losing context
- Your projects compound — each session builds on the last
- New collaborators can pick up your project by reading 1 file

---

## The handoff doc format

Save as `CONTEXT-HANDOFF-MMM-DD-SESSION-N.md` at the root of your project (or in a `/handoffs/` folder).

### The template

```markdown
# Session N Handoff — [Date]

## What we did this session
- [Bullet of what was shipped]
- [Bullet]
- [Bullet]

## What's pending
- [Thing started but not finished]
- [Decision made, not yet implemented]
- [Question I need to answer before next session]

## Open follow-ups / known issues
- [Bug found but not fixed]
- [Thing to verify on next session]

## All key files touched this session
- [path/to/file.ext] — what changed and why
- [path/to/another.ext] — what changed

## Credentials / IDs / config you'll need next time
- API key: [reference, not the value — point to .env or memory]
- Pixel ID, campaign ID, customer ID — all named with their actual values

## What the next session should pick up
[2-3 sentences naming the exact next concrete step, with enough context to start cold]

## The exact prompt to start the next session
"Continue from [this filename]. I want to [specific goal]. Pick up at [the step from 'what's pending']."
```

### What makes it work

- **Specific filenames** (not "the config file" — `config/auth.ts`)
- **Specific decisions** (not "we'll use auth" — "we picked Sign in with Apple, scoped to email only")
- **A starting prompt** (the literal sentence you'd say to begin next session)

The starting prompt is the magic. Copy/paste it into your next session and the AI catches up instantly.

---

## How to make Claude write it for you

You don't write the handoff doc yourself. You ask Claude to write it at the end of each session.

### The end-of-session prompt

```
We're wrapping this session. Write a handoff doc at the project root
named CONTEXT-HANDOFF-[MMM-DD]-SESSION-[N].md.

Use this format:
- What we did this session (bullet list)
- What's pending
- Open follow-ups / known issues
- Key files touched (with paths)
- Credentials / IDs / config to reference next time
- What the next session should pick up
- The exact prompt to start the next session

Be specific. Use actual filenames and decision names, not "the config file."
Save it. Don't summarize back to me — just save.
```

That's the prompt. Run it at the END of every session. 60 seconds.

---

## The naming convention

Number every session. Date every session. Both.

```
CONTEXT-HANDOFF-MAY-27-SESSION-25.md
CONTEXT-HANDOFF-MAY-28-SESSION-26.md
CONTEXT-HANDOFF-JUN-02-SESSION-27.md
```

- **Date** = when it happened
- **Session number** = how many total sessions on this project

The session number gives you a sense of project momentum. "Session 25" tells you this is a serious project — your future-self will treat it that way.

---

## Where to save handoffs

### Option A: Project root
For small projects with 1–10 sessions. Top of repo. Easy to find.

### Option B: /handoffs/ folder
For larger projects. Lives in `/handoffs/CONTEXT-HANDOFF-MMM-DD-SESSION-N.md`. Keeps your project root clean.

### Option C: Commit them
If your project is in git, commit handoff docs. Now they live with the code and you can see when project context shifted alongside code changes.

> 💡 **Operator tip:** Commit and push the handoff doc as the LAST thing you do each session. It's a clear "I'm done for today" signal — and if your laptop dies overnight, the handoff survives.

---

## The starting ritual (next session)

When you start a new session:

1. Open the LATEST handoff doc
2. Copy the "exact prompt to start the next session" line
3. Paste into Claude Code as your opening message

That's it. Claude reads the handoff (which references the relevant code/files), and you're back in flow in 90 seconds.

---

## What a good handoff doc looks like (real example)

```markdown
# Session 25 Handoff — 2026-05-27

## What we did this session
- Launched Sprint to Summer Meta ad (Herbalife VIP campaign)
- Bumped workhorse ad budget from $15 → $35/day
- Wrote revenue PRD (NUTRITION_HUB_REVENUE_PRD.md) — appendix D covers new-location playbook
- Installed Meta Pixel on order.nutritionhub101.com + landing page
- Installed Conversions API (CAPI) server-side with dedup via event_id
- Verified ad URL ronnie-nutrition.github.io allowlisted

## What's pending
- Domain Verification (separate from allowlist — needed for iOS 14.5+ attribution)
- Roll PRD playbook out to second location (TBD which)

## Open follow-ups / known issues
- Landing page repo (Nutritionhub-landing) was 1 commit behind GitHub (pixel-add commit only on remote) — must pull before editing
- InitiateCheckout count inflated on landing button (will address next session)

## All key files touched this session
- nutritionhub-landing/index.html — added Meta Pixel browser snippet
- nutritionhub-landing/menu/server.js — added CAPI Purchase handler + Advanced Matching
- nutritionhub-landing/menu/index.html — added pixel + InitiateCheckout fire
- nutritionhub-landing/menu/NUTRITION_HUB_REVENUE_PRD.md — created with Appendix D

## Credentials / IDs / config you'll need next time
- Meta Pixel ID: 915336731481586
- Meta workhorse campaign: 120244072563520092 ("Local Pearland - Conversion Experiment")
- Meta CAPI token: env var META_CAPI_TOKEN
- GHL location: HJl01216dIdKMhk1SSn1

## What the next session should pick up
Roll the PRD playbook to a new location. Need to know:
(1) what city/vertical, (2) current daily revenue, (3) competitor density.

## The exact prompt to start the next session
"Continue from CONTEXT-HANDOFF-MAY27-SESSION25.md — I want to apply the PRD
playbook to [NEW LOCATION]. It's a [vertical], in [city], doing $___/day."
```

That doc lets future-Ronnie (or a contractor, or me) start the next session in seconds.

---

## Why this works psychologically

Without a handoff doc:
- You re-explain context for 20 min
- You forget details ("wait, what was the pixel ID again?")
- The AI fills gaps with guesses
- Errors compound across sessions

With a handoff doc:
- Context is explicit, not "in your head"
- Decisions are durable
- The project belongs to the WRITTEN STATE, not your memory
- You can pause and resume freely

---

## Common questions

**Q: Doesn't Claude have memory now?**
A: Yes, but it's limited (200K context, expires across sessions, varies by interface). The handoff doc is the AI-agnostic version that works across Claude, Cursor, Codex, anywhere.

**Q: What if I forget to write one at session end?**
A: Run the prompt at the start of the NEXT session — "Based on this conversation history, write a backward-looking handoff doc for the previous session." Claude will reconstruct from what it can see.

**Q: How many sessions before this matters?**
A: After session 2, you'll feel the loss. After session 5, the handoff doc saves an hour/week. After session 10, the project is impossible without it.

**Q: Can I use this for non-code projects?**
A: Yes. Marketing planning, content calendars, business strategy — anything multi-session benefits from the handoff pattern. The template stays the same.

**Q: Should the handoff be private (gitignored) or public (committed)?**
A: Committed unless it has secrets. The handoff doc IS the project's documentation. Treat it like one.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Claude Code / Cursor / any AI tool | Write handoffs | (already using) |
| Git repo | Persist handoffs across sessions | Free |
| **Time** | **60 sec/session end + 90 sec/session start** | — |

---

## What's next

That's the last skill in this kit. You now have:
- 2 hero PRDs (iOS app + Meta ads)
- 13 supporting skills (outreach, content, ads, CRM, loyalty, operations)
- This meta-skill that makes ALL of them durable across time

Use the handoff doc pattern on every project you run through this kit. It's the compounding habit that makes 15 skills feel like 50.
