# Bring-A-Friend Lead Magnet System

**The referral mechanic that turns one happy customer into 1–3 new ones — without you doing any outreach.**

> *Written by Ronnie Craig — operator running a bring-a-friend mechanic at my Pearland nutrition club. A meaningful share of my regulars bring at least one friend in their first month.*

---

## What this PRD is

The cheapest customer to acquire is the friend of an existing customer. Trust is pre-built. Skepticism is low. Conversion rate is 3–5x higher than cold leads.

Most operators DON'T have a system to make this happen, so they wait for organic word-of-mouth and get crumbs.

This PRD teaches you the exact mechanic to ENGINEER word-of-mouth:

1. The 2-sided offer that makes both parties win
2. The visit-day pitch (timing matters)
3. The follow-up that closes the loop
4. The tracker that proves the mechanic is working

## Who this is for

- Local biz with repeat customer dynamics (gym, food, salon, services)
- E-commerce with shareable physical products
- SaaS with team/family use cases
- Any business where the customer's network has 3+ people who'd also benefit

## Outcome

After implementing:
- A meaningful share of customers bring at least one friend in their first month
- Customer acquisition cost drops by 50–70% on the referred segment
- Existing customers become stickier (they have a friend in your business now)

---

## The 2-sided offer

The mechanic only works if BOTH parties win. Asymmetric offers (just the existing customer gets something) feel transactional and convert poorly.

### The structure

> **Existing customer brings a friend → both get [the value].**

### Examples that work

- "Bring a friend, both get a free [product]."
- "Bring a friend, both get 20% off this visit."
- "Bring a friend, both get [bonus item] added to their order."

### Why 2-sided

- The existing customer doesn't feel like they're "doing your marketing"
- The friend doesn't feel like they're being recruited into a sales pitch
- Both feel like they're in on something good together

### What to avoid

- ❌ "Refer 3 friends, get $5 off" (too transactional, too high a bar)
- ❌ "Give a friend $10 off" (only friend benefits — no incentive for existing customer)
- ❌ Cash referral bonuses (feels MLM, repels normal people)

---

## The visit-day pitch (timing matters more than wording)

### When to pitch the bring-a-friend offer

**Pitch it on visit 2 or 3, NOT visit 1.**

- Visit 1: First impression. They're still figuring out if you're legit. Don't pitch yet.
- Visit 2: They came back voluntarily. They're warming up. Mention casually.
- Visit 3: They're now a regular. Make the formal pitch.

### The casual mention (visit 2)

While they're at the counter / chair / receiving the product:

> "Glad you came back. By the way — anytime you bring a friend with you, both of you get [the offer]. Just so you know."

That's it. No pressure. No follow-up. You planted the seed.

### The formal pitch (visit 3)

> "Hey [name], you're a regular now — so I wanna make sure you know about our 'bring a friend' deal. Anytime you come in with someone new, both of you get [the offer]. Anyone in your life I should be expecting?"

That last question — "anyone I should be expecting?" — is the close. It gets them to NAME a specific person, which dramatically increases the chance they actually bring them.

### The follow-up DM (24 hrs after visit 3)

> "Hey [name], appreciate you again today. If you bring [name they mentioned] in this week, I'll have your bring-a-friend [offer] set up for both of you. Just give me a heads-up so I can make it good."

You're using the specific name they said. Personal, specific, low-friction.

---

## The "skip visit 1" trick

A common variation: invite the friend BEFORE the existing customer's first paid visit.

### How it works

After a great free-first-visit (skill #7), you say:

> "Glad you liked it. Real quick — anytime you bring a friend who hasn't been here, BOTH of you get [the offer]. So if you have someone in mind, save us the second free visit for them and come together."

This converts the customer's NEXT visit into a 2-person visit. Often the friend isn't even needed as the "next visit" — they're an extra visit on top.

---

## The visit experience for a bring-a-friend pair

When they show up together, the experience needs to feel celebrated, not transactional.

### The 3-step welcome

**1. Recognize the regular.**
"You're back! And who's this?"

**2. Welcome the friend BY NAME.**
"[Friend's name], glad you came. [Regular] said good things — what brings you in today?"

**3. Make BOTH products.**
At the same time. Not the regular's first. Both at once. Equal energy.

### Optional: ask for the social media tag

If the visit went well:

> "If you both wanted to do a quick photo, I'd love to share it. No pressure though."

Most people say yes. You now have a shareable post for your content engine.

---

## Tracking the mechanic

Every bring-a-friend visit needs to be logged. Otherwise you can't tell if the mechanic is working.

### Minimum tracker columns

| Column | What it holds |
|---|---|
| Date | When they came in |
| Existing customer | Name of the regular |
| Friend | Name of the new person |
| Both ordered? | Yes/No (did both get a product?) |
| Friend returned within 14 days? | Yes/No (this is the KPI) |

### The KPI that matters

> **% of bring-a-friend visits where the friend comes back within 14 days as a paying customer.**

If that's >40%, your mechanic is working. If <20%, the experience needs improvement.

---

## Common failure modes

### Failure 1: Pitching too early
You mentioned it on visit 1. They didn't trust you yet. They never came back. **Fix:** Wait until visit 2 or 3.

### Failure 2: Friend feels like a "lead" not a "guest"
You launched into a sales pitch when they walked in. They felt like a target. **Fix:** Treat the friend like the existing customer — equal energy, no pitch.

### Failure 3: Confusing offer
"Bring a friend, get 10% off your 4th visit if they come on a Tuesday." Nobody remembers that. **Fix:** ONE offer, ONE rule. "Both get free [product]."

### Failure 4: No follow-up after the friend leaves
Friend came, got the free thing, never returned. **Fix:** Run the post-free-visit follow-up sequence (skill #7) on the new friend.

---

## Stacking with other systems

The bring-a-friend mechanic compounds with:

- **Free-First-Visit (skill #7)** — Use bring-a-friend to convert visit 3+ into 2-person visits
- **Content-First Lead Harvest (skill #4)** — Post the photos from bring-a-friend visits as content
- **GHL Loyalty + Check-In (skill #14)** — Award bonus loyalty points for bring-a-friend visits
- **Brand Voice (skill #6)** — Frame the mechanic in the No-BS Truth-Teller voice ("I'd rather you bring a real friend than I run ads")

---

## Common questions

**Q: What if the customer's friend doesn't want to come?**
A: Don't pressure. Just say "if you ever do, the offer's open." Most operators ruin this by pushing.

**Q: Can I do this for online/e-commerce?**
A: Yes. The "bring a friend" becomes a referral link with a 2-sided discount. Same psychology, different mechanic.

**Q: Should I cap the number of friends?**
A: For v1, no. Most customers bring 1, occasionally 2. The cap is built into the offer (it has to be in-person, on the same visit).

**Q: What if the existing customer abuses it?**
A: Track. If someone is bringing 1 person/week, they're either a super-spreader (jackpot) or running a side hustle (rare). Either way, you'll know from your tracker.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Your CRM / Sheet | Track bring-a-friend visits | Free |
| The actual offer | The cost of 2 free products per pair | $$ varies |
| **Time** | **5 min/pair** | — |

---

## What's next

You now have two complementary local biz acquisition systems: **Free-First-Visit (skill #7)** brings in cold leads. **Bring-A-Friend (this PRD)** turns warm customers into a referral engine.

Both feed your CRM. The **GHL Quick-Start (skill #13)** and **Loyalty + Check-In (skill #14)** tell you how to manage that customer base once it grows.
