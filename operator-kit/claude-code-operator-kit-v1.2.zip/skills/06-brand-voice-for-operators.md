# Brand Voice for Operators: How to Build a Brand Voice That Doesn't Sound Like AI

**The 90-minute system to find YOUR voice, then teach Claude / ChatGPT / any AI to write in it — without sounding like everyone else's generic AI content.**

> *Written by Ronnie Craig — operator who built a recognizable brand voice for my Pearland nutrition club. The voice is the reason customers DM me saying "I read every post" instead of scrolling past.*

---

## What this PRD is

It's 2026. Everyone uses AI to write content. Most of it sounds the same — bland, generic, "in today's fast-paced world" sludge that fades into noise the second it hits a feed.

The operators who win in this environment do ONE thing differently: they **train AI on a real brand voice**. Not a brand voice they bought from a template. Not a "voice" their consultant invented. The voice they ACTUALLY use when talking to a customer at the counter.

This PRD teaches you how to:

1. Find YOUR voice (the one already inside you, just not written down yet)
2. Encode it as a 3-pillar framework AI can follow
3. Train Claude / ChatGPT to write in YOUR voice (not generic AI voice)
4. Test your voice so a friend who knows you would recognize it
5. Keep the voice consistent across captions, DMs, emails, and ads

## Who this is for

- Operators and small biz owners writing your own content
- Coaches, consultants, creators whose marketing sounds like everyone else's
- People using AI tools whose output reads like "AI sludge"
- Anyone wondering why content takes hours and still doesn't feel like *you*

## Outcome

After running this PRD (~90 minutes total):

- A written voice doc that captures YOUR pillars, YOUR receipts, YOUR signature phrases
- A Claude prompt that produces content in YOUR voice — not generic AI voice
- The ability to spot AI sludge in your own drafts and rewrite it instantly
- Brand recognition: people DM you saying "I knew that was you before I saw the name"

---

## Why your AI content sounds like AI (and your competitors' does too)

Quick diagnosis. The 4 reasons 90% of operator content reads like sludge:

### 1. You're using AI without giving it a voice prompt
You ask Claude / ChatGPT to "write a caption about my new product." Without a voice spec, it defaults to its training data's average — which is corporate blog posts. Result: bland.

### 2. You're writing from theory, not experience
"Consistency is the key to results" is a theory. "Crystal stopped after 6 weeks, lost 7 lbs, then almost quit on week 4" is experience. AI defaults to theory. You have to feed it experience.

### 3. You're using industry-standard language
Every wellness brand says "unleash your potential." Every coach says "transform your life." Every SaaS says "streamline your workflow." If your sentence could appear on 1,000 other brands' Instagrams, it's not your voice.

### 4. You're writing from "the brand's" perspective, not yours
"At Nutrition Hub, we believe in…" is brand voice. "I sold supplements for 4 years before opening Nutrition Hub and here's what I learned…" is YOUR voice. The first sounds like a press release. The second sounds like a person.

The fix is voice. Specifically, **your voice, with structure.** That's what this PRD builds.

---

## The 3-pillar framework (the structure ANY operator voice can use)

This framework is the structure. The CONTENT inside each pillar is what makes the voice yours — not mine, not your competitor's, yours.

### Pillar 1: Credible Insider
You speak from real experience, not theory. Every claim is backed by a thing YOU did.

- ❌ "Successful entrepreneurs prioritize their morning routine."
- ✅ "I tried 5 morning routines over 2 years. Only one stuck: 10 min outside, no phone, coffee. Skip the rest."

### Pillar 2: No-BS Truth-Teller
You're willing to name the cliché in your industry and offer the truth in its place.

- ❌ "Discover your wellness journey with our holistic approach."
- ✅ "Half the supplements in the gym are trash. A protein scoop and a multivitamin do 90% of the work."

### Pillar 3: Story-First Teacher
You teach through specific stories with real names, dates, and outcomes — not abstract lessons.

- ❌ "Consistency is the key to results."
- ✅ "Crystal came in last April, 145 lbs, body aches every morning. 6 weeks later: aches gone, lost 7 lbs. The first week was the worst."

That's the framework. Three pillars. Now we build YOURS.

---

## Phase 1: The voice self-audit (10 minutes)

5 questions. Get a notebook (or open a doc). Answer each in 2–4 sentences. Don't overthink — your first instinct is usually the truest.

### Q1. What's the ONE thing in your industry you'd push back on if a stranger asked your honest opinion?

Examples:
- (Nutrition) "Most supplements are trash. People should learn to cook before they buy powders."
- (Real estate) "Most agents oversell open houses. Half my sales close without one."
- (SaaS) "Most 'AI productivity tools' just add another tab. They don't save time."

This question seeds your **No-BS pillar.**

### Q2. What's a real moment with a real customer / client / person you remember vividly?

Don't make one up. Pull a real one from the last 30 days. Who was it? What did they say? What was the outcome?

This seeds your **Story-First pillar.**

### Q3. What have you DONE — concretely, with numbers — that gives you a right to your opinions?

Not credentials. Receipts.
- "I've sold 50,000 smoothies."
- "I've shipped 3 iOS apps."
- "I've coached 47 people through a 21-day plan."
- "I worked 8 years in hospice before I started my business."

This seeds your **Credible Insider pillar.**

### Q4. What word or phrase do you ACTUALLY say a lot — that your friends would recognize as yours?

Examples:
- "Real talk…"
- "Cut the noise."
- "Here's the deal."
- "I'm not gonna lie to you…"
- "The math is the math."

These are your **signature phrases.** AI can't invent them. Only you have them.

### Q5. What kind of person do you NEVER want to sound like in your content?

Be specific.
- "Polished corporate marketing person"
- "Wellness influencer with the soft voice"
- "Crypto bro"
- "Self-help guru with the white background"

This becomes your **anti-voice** — what to filter OUT.

---

## Phase 2: Mine your past content (30 minutes)

Your voice is already there. You just haven't written it down. Time to extract it.

### The extraction exercise

**Pull 30 samples** from any of:
- Old Instagram captions
- DMs you've sent (look at the long ones to friends or customers)
- Voice memos you sent someone
- Customer reviews you've written
- Text messages where you got fired up about something
- The transcript of a podcast you were on
- That email you wrote at midnight where you said exactly what you meant

**Read all 30 in one sitting.** Highlight or underline:

1. Any phrase that sounds like YOU (signature words, rhythms, ways you say things)
2. Any specific number, name, or detail you naturally include
3. Any time you took a stand or pushed back on conventional wisdom
4. Any story you told that had a real moment in it

These highlights are the raw material of your voice. Most operators have HUNDREDS of voice-rich phrases in their past content — and zero of them in their current AI-generated content. The work is to bring the past content forward.

### What you'll discover

Most operators are shocked when they do this exercise. Common patterns:

- You're FUNNIER in your old DMs than in your current marketing
- You're MORE SPECIFIC in your customer reviews than in your captions
- You're MORE OPINIONATED in your texts than in your posts
- You have a FEW phrases you say constantly that you didn't realize were yours

That's your real voice. It's hiding in your sent box.

---

## Phase 3: Fill in YOUR 3 pillars (30 minutes)

Open a new file: `MY_VOICE.md`. This is your voice doc — the artifact this PRD produces. You'll reference it forever.

### The template

Copy and fill in:

```markdown
# My Brand Voice — [Your Name / Business]

## Pillar 1: Credible Insider — What I've actually done

What I bring to every claim:
- [Number / receipt / experience #1]
- [Number / receipt / experience #2]
- [Number / receipt / experience #3]
- (Aim for 5–10 receipts. These prove you're not theorizing.)

How this shows up in content:
- I lead with "I tried…" "I noticed…" "When I…" not "Studies show…" not "Best practices…"
- I name specific products, customers, dates, and numbers
- I never use credentials when I have receipts

## Pillar 2: No-BS Truth-Teller — What I'll name that nobody else will

Things I'll say that my industry won't:
- [Industry cliché I disagree with #1] → [What I'd say instead]
- [Industry cliché I disagree with #2] → [What I'd say instead]
- [Industry cliché I disagree with #3] → [What I'd say instead]

How this shows up in content:
- I name the BS, then offer the truth
- I refuse the sale upfront when it's not a fit
- I admit what doesn't work, including for me

## Pillar 3: Story-First Teacher — How I teach

Real stories I'll tell repeatedly:
- [Customer #1 name, what happened, the lesson]
- [Customer #2 name, what happened, the lesson]
- [Customer #3 name, what happened, the lesson]
- (Update this list quarterly as new stories happen.)

How this shows up in content:
- I start with a moment, not a lesson
- I include the unsexy part (doubt, grind, almost-quit)
- I end with one sentence of takeaway, not a paragraph

## My signature phrases
(From Phase 1 Q4 + Phase 2 extraction)
- "[Phrase #1]"
- "[Phrase #2]"
- "[Phrase #3]"
- (5–15 phrases.)

## My anti-voice (NEVER sound like this)
(From Phase 1 Q5)
- Avoid: [type of voice #1]
- Avoid: [phrases that would make me sound like that voice]

## My banned words / phrases
- "Unleash"
- "Transform"
- "Journey"
- "Holistic"
- "Synergy"
- "Best-in-class"
- (Add yours from the extraction exercise — things that sounded like AI-sludge when you read them.)
```

### The rule

**Every section is filled in with specifics from YOUR life, not generic placeholders.** If a section reads like a template, you didn't do it.

---

## Phase 4: The voice test (20 minutes)

Now we check if your voice doc actually works.

### The test

Pick a topic — anything you'd realistically post about. Examples:
- A new product or service you're launching
- A common customer question
- Something annoying that happened today
- An opinion you'd defend at a dinner party

Write **3 short posts** (2–4 sentences each) using your voice doc. Reference your pillars, signature phrases, banned words. Don't use AI — write them by hand.

### The aloud check

Read each post out loud. Ask yourself:

1. Does this sound like ME if a friend who knows me read it without my name on it?
2. Could this sentence appear on a competitor's account? (If yes, rewrite.)
3. Did I lead with a moment or a lesson? (Moments win.)
4. Are there any banned words? (Cut.)

### The friend check (optional but powerful)

Send the 3 posts to ONE friend who knows you well. Don't tell them what they are. Ask: "Does this sound like me?"

- ✅ "Yeah totally" → voice doc works
- ⚠️ "Kinda, but [X] is off" → adjust the doc, retest
- ❌ "No, doesn't sound like you" → restart Phase 2, you skipped the extraction

---

## Phase 5: Train AI to write in YOUR voice (15 minutes)

Now we make AI work FOR your voice instead of against it.

### The voice-prompt for Claude / ChatGPT

Paste your `MY_VOICE.md` file into a new conversation. Then save this prompt as a snippet you reuse:

```
You're writing in my brand voice. The voice doc above is the source of truth.

Rules:
1. Every claim cites something from my "Credible Insider" pillar — a real experience or number, never theory.
2. You may name an industry cliché and offer my counter-truth — but only one per piece, max.
3. Lead with a SPECIFIC MOMENT (with a name or date) when possible, not an abstract lesson.
4. Use 1–3 of my signature phrases naturally — never force them.
5. Banned: any word on my banned list. Re-write the sentence if you find one.
6. Anti-voice: do NOT sound like the voice types I listed under "my anti-voice."

Now write a [caption / DM / email / ad / etc.] about [topic].

After you draft, do a self-check:
- Does it lead with a moment?
- Does it use a banned word? If yes, rewrite.
- Could this sentence appear on a competitor's account? If yes, rewrite.

Show me the draft + the self-check.
```

### Why this works

The prompt does three things AI usually skips:

1. **Forces it to use YOUR receipts** instead of inventing generic claims
2. **Forces it to self-check** — catches sludge before you do
3. **Names the anti-voice** — gives the AI something specific to AVOID, not just "be authentic"

### After the AI drafts

Read it out loud. Apply the same aloud check from Phase 4. If anything sounds AI, rewrite by hand. Over time you'll need fewer hand-edits — the prompt gets sharper as you refine your voice doc.

---

## How to never sound like AI again — quick reference

Pin this above your desk:

### Before you post, check:

- [ ] Did I lead with a moment, not a lesson?
- [ ] Did I name a specific person, number, or date?
- [ ] Did I say anything an average competitor wouldn't say?
- [ ] Is every banned word gone?
- [ ] Would a friend recognize this as me?

### If any answer is "no" — rewrite that line.

### Common AI tells (and how to fix them)

| AI sludge | Fix |
|---|---|
| "In today's fast-paced world…" | Cut entirely. |
| "Many people struggle with…" | Replace with "Last week, [name] told me she struggles with…" |
| "Discover…" | Replace with "I figured out…" |
| "Unleash your potential" | Just delete this sentence. |
| "Transform your journey" | Same. |
| Long lists of adjectives | Pick ONE adjective. The right one. |
| Closing with "What do you think?" | Only if you actually want the answer. Otherwise end with a statement. |
| Em dashes everywhere | Max 1 per post. |
| Emojis at the start of every line | Max 1–2 per post. |
| "It's important to…" | Cut. Or replace with "I learned this the hard way: …" |

---

## Common questions

**Q: Won't I sound like Ronnie if I use his framework?**
A: No — the framework is the structure. The CONTENT (your receipts, your truths, your stories) is what makes the voice yours. Two people using this framework will sound nothing alike if they did Phases 1 and 2 honestly.

**Q: I'm boring. I don't have stories or opinions.**
A: You do. You just haven't written them down. Phase 2 is built for exactly this — your voice is in your sent box and your DMs. Mine them.

**Q: How often should I update my voice doc?**
A: Quarterly. Add new stories from the last 3 months, new receipts (you've done more), and any new signature phrases you've started using. Voice grows with you.

**Q: Can I use this for B2B?**
A: Yes — especially for B2B. B2B is drowning in corporate sludge. An operator voice cuts through immediately because nobody else there sounds human.

**Q: What if my industry is regulated (medical, legal, financial)?**
A: The pillars still work. You just adjust what you can say. Credible Insider becomes "case studies of clients I've worked with." No-BS becomes "naming common misconceptions in my field." Story-First becomes "patient outcomes" or "client outcomes." The structure is the same; the specifics adjust.

**Q: Can my team or VA write in my voice using this doc?**
A: With practice, yes. The voice doc gives them the rules and the receipts. They'll never write 100% like you, but they'll get to 70–80% — which is enough for most surfaces (replies, DMs, basic captions). Save the hero content for yourself.

**Q: What if I don't have any past content to mine?**
A: Use any text-based output of YOU: text messages, emails, podcast transcripts, voice memo transcripts, even spoken sentences your spouse or coworker remembers you saying. The voice exists wherever you communicate naturally — just capture it.

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| A notebook or any text editor | Run the audits + write the voice doc | Free |
| Past DMs / captions / texts | Source material for extraction | Free |
| Claude / ChatGPT / any LLM | Where you'll deploy your voice prompt | $0–$20/month |
| **Time** | **~90 min to build, 5 min/post to deploy** | — |

---

## What's next

You now have a voice. Use it across every surface — captions, DMs, emails, ads. The voice plugs directly into:

- **Content-First Lead Harvest Workflow** (skill #4) — your harvested DMs go out in your voice
- **100-Conversation Daily Outreach System** (skill #3) — your outreach messages use your signature phrases
- **Free-First-Visit Conversion Lever** (skill #7) — your DM scripts adapt to your voice
- **Meta Ad Operator PRD** (skill #2) — your ad copy uses your voice, not generic ad-speak

The voice is the engine. Without it, every skill in this kit produces generic output. With it, every skill compounds.

**One last thing.** The biggest lie in marketing is that "authentic" voice means "anything goes." It doesn't. Authentic voice is highly STRUCTURED — three pillars, fixed receipts, banned words, signature phrases. The structure is what lets the voice be consistent, scalable, and AI-trainable. Most people skip the structure, then wonder why their voice doesn't show up reliably.

Don't skip the structure. Then go close some sales.
