# Custom Audience Builder for Small Biz

**The 5 audiences every small biz operator should build in Meta — in priority order, with the data sources to feed each.**

> *Written by Ronnie Craig — operator running a workhorse ad against a custom audience built from CRM data + post engagers. CTR has stayed above 4% for 3+ months because the audience is HOT.*

---

## What this PRD is

Meta's biggest lever isn't creative. It's audience. A mediocre ad against a hot audience beats a great ad against a cold one every time.

But Meta's audience builder is confusing — there are 12 types of custom audiences, 3 ways to upload data, and most operators end up using none of them and just running broad geo targeting.

This PRD teaches you the **5 custom audiences that matter for small biz**, in priority order, with the exact data sources to feed each.

## Who this is for

- Local biz owners with a customer list (even a small one)
- E-commerce stores with website visitors
- SaaS or services with an email list
- Operators using Meta ads but defaulting to "broad geo + interest" targeting

## Outcome

After this PRD, you'll have:
- 1–5 custom audiences built in Meta, each tied to a real data source
- A clear hierarchy: which to target first, which to layer in, which to reserve
- Lookalike audiences for scale once your seed audiences are warm
- The settings to use these audiences correctly in your ad set

---

## The 5 audiences (in priority order)

### Audience 1: Existing customers (your CRM list)

**What it is:** Your paying customers, uploaded to Meta as a custom audience.

**Why it's #1:** They already bought. Their faces, behaviors, and lookalike patterns are the SINGLE BEST signal Meta can have for finding more like them.

**How to build it:**

1. Export your customer list to CSV with these columns (more = better matching):
   - Email (lowercase)
   - Phone (digits only, with country code)
   - First name (lowercase)
   - Last name (lowercase)
   - City, state, ZIP, country

2. In Meta Events Manager: **Audiences → Create Audience → Custom Audience → Customer List**

3. Upload the CSV. Meta will hash and match it. You need 100+ matched customers for a useful audience.

**How to use it:**
- ✅ Target directly for upsells, loyalty offers, return campaigns
- ✅ Use as a SEED for lookalikes (audience #4 below)
- ❌ Don't use for new customer acquisition — they're already customers

---

### Audience 2: Website visitors (pixel-based)

**What it is:** Everyone who hit your website in the last 30/60/180 days.

**Why it matters:** They've heard of you. Showing them an ad lowers the cost-per-click because there's no awareness gap.

**How to build it:**

1. **Audiences → Create Audience → Custom Audience → Website**
2. Pick your pixel
3. Set rule: "All website visitors" or "People who visited specific pages"
4. Set retention window: 30 days (start tight, expand if too small)

**Common variants to build:**

| Audience | Rule | Use for |
|---|---|---|
| All visitors, 30d | All who visited any page | Retargeting general traffic |
| Cart abandoners | Visited /checkout, NOT /thank-you | Cart recovery ads |
| Product viewers | Visited any /product/* | Reminder ads |
| Pricing viewers | Visited /pricing | High-intent retargeting |

**How to use it:**
- ✅ Run a separate retargeting campaign at low budget ($5–10/day) to recover lost visitors
- ✅ EXCLUDE from your acquisition campaign (no point spending to re-reach people who already know you)

---

### Audience 3: Social engagers (Facebook + Instagram)

**What it is:** People who liked, commented, saved, or messaged your FB Page or IG account.

**Why it matters:** They engaged with your brand for free. They're warmer than cold, colder than customers — perfect middle.

**How to build it:**

1. **Audiences → Create Audience → Custom Audience → Facebook Page** (or Instagram Account)
2. Pick your page / account
3. Set rule: "People who engaged with any post or ad" — last 365 days

This audience refreshes automatically — Meta keeps adding engagers as they come in.

**How to use it:**
- ✅ Run a separate ad set against this audience at modest budget
- ✅ Use as a SEED for lookalikes
- ✅ Layer into your acquisition campaign as an "include" once it's >5,000 people

---

### Audience 4: Lookalikes (the scale lever)

**What it is:** Meta finds people who LOOK LIKE your seed audience (customers, engagers, etc.).

**Why it matters:** This is how you scale acquisition. Once you have a profitable seed audience, lookalikes find more people like them.

**How to build it:**

1. **Audiences → Create Audience → Lookalike Audience**
2. Source: pick your customer list (#1) or social engagers (#3)
3. Location: pick your country, then narrow by state/region if local
4. Audience size: Start with **1% lookalike** (most similar to seed)

**Sizing strategy:**

| Lookalike % | When to use |
|---|---|
| 1% | Start here. Tightest match to seed. Smaller audience. |
| 1–3% | Expand once 1% saturates (CPM rises, CTR drops) |
| 3–10% | For scaling further; less similar to seed |
| 10%+ | Approaching broad — probably too loose |

**How to use it:**
- ✅ Use as your primary acquisition audience after you have a working seed
- ✅ Test 1% vs. 3% as separate ad sets to find the sweet spot

---

### Audience 5: Geo + interests (the cold fallback)

**What it is:** Pure broad targeting — location + age + maybe 1 interest.

**Why it's last:** Because every other audience is warmer. But for brand-new accounts with no data, this is where you start.

**How to build it:**

In the ad set, under Audience → Detailed Targeting:

- **Geo:** 5–25 mi radius from your location (local biz) or 1 state at a time (e-commerce)
- **Age:** 18–65
- **Gender:** All
- **Languages:** English (US)
- **Detailed targeting:** ONE interest max (or NONE if you have <50 conversions/week)
- **Advantage detailed targeting:** ON

**When to use:**
- ✅ When you have no customer data yet
- ✅ As a "control" ad set alongside your custom audiences
- ❌ NOT as your only audience strategy long-term

---

## The audience priority ladder

Use this priority order:

| Stage | Audience to run |
|---|---|
| **Week 1 (no data)** | Geo + interests (#5) — pure cold |
| **Week 2-4** | Add Website visitors retargeting (#2) at $5/day |
| **Month 2 (you have ~100 customers)** | Add Customer list (#1) for upsells |
| **Month 2** | Add Social engagers (#3) as separate ad set |
| **Month 3 (after first 50 customers)** | Build Lookalikes (#4) as primary acquisition |

---

## How to use these in the ad set

This is where most operators get confused. Here's how the audiences combine.

### Single-audience ad set (start here)

In the ad set, under "Custom Audiences," include ONE audience. Don't mix.

**Example:**
- Include: 1% Lookalike from Customer list
- Exclude: Existing customer list (so you don't re-target people who already bought)

That's it. Don't add interests, don't add behaviors. Let the audience do the work.

### Multi-audience strategies (advanced)

After 30 days of data, you can experiment:

| Strategy | Setup |
|---|---|
| **Stacked custom audiences** | Include: Customer list + Social engagers + Website visitors (Meta dedupes overlaps) |
| **Layered lookalike + interest** | Include: 1% Lookalike + Interest (broad) |
| **Exclusion stacking** | Exclude: Customers + Past converters + Job titles you don't sell to |

Don't stack until your single-audience baseline works.

---

## Audience size guidelines

| Audience size | Verdict |
|---|---|
| < 1,000 | Too small. Either Meta won't deliver, or it'll burn out in days. |
| 1,000 - 10,000 | OK for hyper-local retargeting. Spend modestly. |
| 10,000 - 100,000 | Sweet spot for most small biz. |
| 100,000 - 1M | Great for scale. |
| 1M+ | Likely too broad unless you have huge budget. |

---

## Common questions

**Q: My customer list has only 50 people. Can I still upload it?**
A: Yes, but Meta will tell you it's too small for direct targeting. You can still use it as a seed for lookalikes once it's 100+.

**Q: Should I exclude my customer list from acquisition ads?**
A: Almost always yes. No point spending acquisition $$ on existing customers.

**Q: How often should I refresh / update my customer list?**
A: Quarterly. Upload the latest CSV; Meta merges automatically.

**Q: My lookalike audience size is huge (2M+). Is that a problem?**
A: Not necessarily — lookalikes are inherently large because Meta is generalizing. The 1% lookalike is the tightest match within that pool.

**Q: My website traffic is tiny. Should I still build the website audience?**
A: Build it — even small audiences accumulate over time. Just don't budget against it until it has 1,000+ people.

---

## What to skip in v1

- ❌ Manual placement targeting (Facebook Feed only, etc.)
- ❌ Detailed behaviors (purchase types, life events, etc.) — Meta deprecated most of these in 2024-2025 anyway
- ❌ Income / wealth targeting — Meta deprecated these
- ❌ Custom interests that you "think" describe your buyer — Meta's algo finds better signals
- ❌ Multiple narrow age ranges — let Meta find within 18-65
- ❌ Multiple custom audiences in v1 — start with one

---

## Tools & costs summary

| Tool | Purpose | Cost |
|---|---|---|
| Meta Events Manager | Build audiences | Free |
| Meta Business Manager | Upload customer lists | Free |
| Your CRM | Export customer CSV | $0 — $$$ depending |
| **Time** | **30 min one-time setup, 10 min/month maintenance** | — |

---

## What's next

You have audiences. You have the workhorse config (skill #9). You have pixel + CAPI (hero #2). Now you need a way to keep the account clean weekly — that's the **Live Ad Audit + Zombie Campaign Sweep** (skill #11).
