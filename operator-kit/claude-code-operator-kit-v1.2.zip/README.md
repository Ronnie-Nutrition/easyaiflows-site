# Claude Code Skills Bundle: The Operator Kit
### 15 PRDs for iOS Apps, Meta Ads & Local Business Growth

> From a guy actually shipping — 3 iOS apps, profitable Meta ads at $35/day, real local business in Pearland, TX.

---

## What's inside

This bundle contains 15 production-tested PRDs (Product Requirements Documents) covering everything an indie operator needs to ship real products and get real customers. Each PRD is a self-contained playbook — you can pick the one that matches your current bottleneck and start there.

The PRDs are designed to work together. Cross-references throughout point you to the next logical skill once you've shipped one.

---

## Two ways to use this kit

This kit ships in **two formats — same content:**

1. **Readable PRDs** → [`skills/`](skills/) — Markdown playbooks for **you** to read and follow. Open them, skim them, paste them into a chat, drop them in a Claude Code project.
2. **Installable Skills** → [`skills-installable/`](skills-installable/) — the same 15 PRDs packaged as `.zip` Claude Skills you can **upload into Claude** (claude.ai → Settings → **Upload skill**). Claude then pulls the right one in automatically when your request matches.

> **Heads up:** if you grab a file straight out of `skills/` and try to upload it as a Skill, Claude will reject it with **"SKILL.md must start with YAML frontmatter (---)"**. That's expected — those are reading copies. For uploading, use the ready-made zips in [`skills-installable/`](skills-installable/); they already have the required header. See that folder's README for the 2-step install.

---

## How to use this kit

1. **Start with the hero PRD that matches your current bottleneck.**
   - Need to ship a product? → Start with `01-ios-app-builder-prd.md`
   - Need to get customers? → Start with `02-meta-ad-operator-prd.md`
2. **Read it end-to-end ONCE.** Then go back and follow it.
3. **When you finish a phase, move to the next PRD it cross-references.**
4. **Use the Session Handoff Doc Pattern (#15) on every project you run through these.**

Each PRD is built to be skimmed AND deep-read. Use the table of contents at the top of each to jump.

---

## Table of contents

### 🔥 Hero PRDs

| # | Skill | What it does |
|---|---|---|
| 01 | [How to Build an iOS App with AI (Without Being a Coder) — PRD Playbook](skills/01-ios-app-builder-prd.md) | Validate → write PRD → pick stack → AI build loop → ship to App Store |
| 02 | [How to Run a Profitable Meta Ad in 2026 — Pixel + CAPI + Optimization Playbook](skills/02-meta-ad-operator-prd.md) | Pixel + CAPI install → optimization event picker → exact workhorse config |

### 💰 Outreach & Content

| # | Skill | What it does |
|---|---|---|
| 03 | [100-Conversation Daily Outreach System](skills/03-100-conversation-daily-outreach-system.md) | Sustainable daily DM rhythm across IG, TikTok, FB, iMessage |
| 04 | [How to Turn Social Media Engagement Into DMs That Close — The Lead Harvest Workflow](skills/04-content-first-lead-harvest-workflow.md) | Content fills the pipeline, DMs close it — the harvest ritual |
| 05 | [2-Strike Cold Rule + Dead Lead Rule](skills/05-two-strike-dead-lead-rule.md) | When to kill a lead and free the slot |
| 06 | [Brand Voice for Operators: How to Build One That Doesn't Sound Like AI](skills/06-brand-voice-for-operators.md) | 90-min system to find YOUR voice + train Claude/ChatGPT to write in it |

### 📈 Conversion & Acquisition

| # | Skill | What it does |
|---|---|---|
| 07 | [Free-First-Visit Conversion Lever](skills/07-free-first-visit-conversion-lever.md) | The offer that beats every discount for local biz |
| 08 | [Bring-A-Friend Lead Magnet System](skills/08-bring-a-friend-lead-magnet-system.md) | Turn one customer into 1–3 more, without outreach |

### 🎯 Meta Ads Tactical

| # | Skill | What it does |
|---|---|---|
| 09 | [The Profitable Meta Ad Config — Field-by-Field Reference Card](skills/09-workhorse-ad-anatomy.md) | Every field in a profitable conversion campaign, set correctly |
| 10 | [Custom Audience Builder](skills/10-custom-audience-builder.md) | The 5 audiences every small biz needs, in priority order |
| 11 | [Live Ad Audit + Zombie Campaign Sweep](skills/11-live-ad-audit-zombie-sweep.md) | The 15-min Monday ritual that catches drift early |
| 12 | [Pixel + CAPI Server-Side Install (Node)](skills/12-pixel-capi-server-side-install.md) | Drop-in Node code with dedup + Advanced Matching |

### 🛠 CRM & Ops

| # | Skill | What it does |
|---|---|---|
| 13 | [GHL Quick-Start for Local Biz](skills/13-ghl-quick-start-local-biz.md) | 30-min Go High Level setup without paying a consultant |
| 14 | [Loyalty + Check-In via GHL Custom Fields](skills/14-loyalty-checkin-ghl-custom-fields.md) | Visit-based loyalty program, no extra app needed |

### 🧠 Meta-Skill

| # | Skill | What it does |
|---|---|---|
| 15 | [Claude Code Memory Hack: The Session Handoff Doc That Saves Your Context](skills/15-session-handoff-doc-pattern.md) | Never lose Claude Code context between sessions again |

---

## How the skills connect

```
                     [iOS App Builder] (01)
                            │
                            ▼
                     YOU HAVE A PRODUCT
                            │
                            ▼
                    [Meta Ad Operator] (02)
                            │
              ┌─────────────┼─────────────┐
              ▼             ▼             ▼
       [Workhorse Ad]  [Custom Aud]  [Pixel + CAPI]
            (09)         (10)          (12)
                            │
                            ▼
                    YOU HAVE TRAFFIC
                            │
                            ▼
              [Free-First-Visit] (07) ──┐
              [Bring-A-Friend] (08) ────┤
                            ▼            │
                    YOU HAVE CUSTOMERS   │
                            │            │
                            ▼            │
                       [GHL] (13)        │
                       [Loyalty] (14)    │
                            │            │
                            ▼            │
                   YOU HAVE A SYSTEM     │
                            │            │
                            ▼            │
            [100-Conv Outreach] (03) ◄───┤
            [Content-First Harvest] (04) │
            [2-Strike Rule] (05) ────────┤
            [Brand Voice] (06) ◄─────────┘
                            │
                            ▼
                    YOU HAVE COMPOUNDING
                            │
                            ▼
              [Live Ad Audit Weekly] (11)
              [Session Handoff Pattern] (15)
                            │
                            ▼
                    YOU HAVE A BUSINESS
```

---

## Who this is for

- **Indie operators** shipping their own products instead of waiting for permission
- **Local biz owners** doing their own marketing and tired of agency theory
- **Coaches / consultants** who want a system, not motivation
- **Non-coders** using Claude Code / Cursor / AI tools to ship real software
- **Anyone in Claude Code groups** who's wondering "how do I actually USE this thing to make money"

This is NOT for:
- People looking for "passive income" courses
- Agency-style consultants who want to talk strategy without execution
- People who want a magic button

Every PRD assumes you're willing to do the work. The work is reasonable. The system makes it efficient.

---

## What's NOT in this kit (and why)

To keep this useful, I cut a lot of "could be helpful" content. Specifically NOT included:

- ❌ Email marketing playbooks (too much SaaS-specific noise; replicate from `06 Brand Voice` if needed)
- ❌ Google Ads PRDs (Meta is the lower-friction starting point for most operators)
- ❌ TikTok-only growth playbooks (`04 Content-First` covers cross-platform principles)
- ❌ Shopify-specific setup (the `12 Pixel + CAPI` works on Shopify with minor tweaks)
- ❌ Cold email at scale (this kit focuses on warm engagement; cold email has its own problem space)

If demand is high, additional volumes might cover these.

---

## A word on the voice

Every PRD is written in the operator voice: Credible Insider, No-BS, Story-First. That voice is explicitly taught in PRD #06.

Some claims reference my specific business (Nutrition Hub in Pearland, TX). They're real receipts, included to ground the lessons. The principles work in any local market — the receipts just prove they're not theoretical.

---

## Pricing and licensing

You paid $24.97 for this bundle. That includes:
- All 15 PRD markdown files (this bundle)
- Lifetime updates (you get any future revisions free)
- Unlimited personal use across your own projects and businesses

It does NOT include:
- Resale rights (don't repackage and resell)
- Agency white-label rights (contact for licensing if you want to use this with clients)

If you found this through a link from someone else and want to verify your purchase or get updates, email me.

---

## What's next

1. **Open the `skills/` directory** (to read) or **`skills-installable/`** (to upload into Claude)
2. **Start with the hero PRD that matches your current bottleneck** (skill #01 or #02)
3. **Follow the cross-links to the next skill** as you finish each phase
4. **Use the Session Handoff Doc Pattern (#15) from day one**

You have everything you need to ship. Go close some sales.

— Ronnie Craig
