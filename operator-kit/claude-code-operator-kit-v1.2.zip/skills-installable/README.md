# Installable Skills — Upload These Into Claude

This folder is the **click-to-install** version of the Operator Kit. Each of the 15 PRDs has been packaged as a real Claude Skill so you can upload it and Claude will pull it in automatically when it's relevant.

> The readable PRD playbooks still live in [`../skills/`](../skills/). Those are for **you** to read. The zips in *this* folder are for **Claude** to install. Same content — two formats.

---

## How to install one

1. Go to **claude.ai** → your **Settings** → **Capabilities / Skills** → **Upload skill**
   (or hit the **Upload skill** button wherever you see it).
2. Drag in **one** of the `.zip` files from this folder.
3. That's it. Claude reads the `name` and `description` and will use the skill when your request matches.

Upload **one zip at a time** — each zip is a single skill.

---

## What's in each zip

```
01-ios-app-builder.zip
└── ios-app-builder/
    └── SKILL.md   ← starts with YAML frontmatter (name + description)
```

That YAML frontmatter at the top of `SKILL.md` is the part the uploader requires. If you ever try to upload a plain `.md` and get the error **"SKILL.md must start with YAML frontmatter (---)"**, it means the file is missing that header block — use the zips here, they already have it.

---

## The 15 skills

| Zip | Use it when… |
|---|---|
| `01-ios-app-builder.zip` | Building an iOS app with AI as a non-coder |
| `02-meta-ad-operator.zip` | Setting up or fixing a profitable Meta ad |
| `03-daily-outreach-system.zip` | Building a daily DM / outreach rhythm |
| `04-lead-harvest-workflow.zip` | Turning social engagement into DMs |
| `05-dead-lead-rules.zip` | Deciding when to drop a lead |
| `06-operator-brand-voice.zip` | Training AI to write in your voice |
| `07-free-first-visit-offer.zip` | Picking a local-biz first-visit offer |
| `08-bring-a-friend-system.zip` | Getting customers to refer friends |
| `09-meta-ad-config-reference.zip` | Building a Meta conversion ad field-by-field |
| `10-custom-audience-builder.zip` | Building Meta custom audiences |
| `11-live-ad-audit.zip` | Running the weekly Meta ads review |
| `12-pixel-capi-install.zip` | Installing Pixel + CAPI on a Node site |
| `13-ghl-quick-start.zip` | Setting up Go High Level fast |
| `14-ghl-loyalty-checkin.zip` | Building a visit-based loyalty program in GHL |
| `15-session-handoff-pattern.zip` | Saving Claude Code context between sessions |

---

— Ronnie Craig
